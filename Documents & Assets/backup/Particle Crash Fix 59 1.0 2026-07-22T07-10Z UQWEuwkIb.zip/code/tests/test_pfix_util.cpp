/*
  test_pfix_util.cpp

  Standalone test
  Host-native unit tests for the portable pure helpers in pfix_util: the
  relocation/displacement arithmetic and the sibling-path builder.
*/

#include "pfix_util.hpp"

#include <cstdint>
#include <cstdio>
#include <cstring>

namespace
{

int failures = 0;
int checks = 0;

#define CHECK(cond)                                                                                                                \
  do                                                                                                                               \
  {                                                                                                                                \
    ++checks;                                                                                                                      \
    if (!(cond))                                                                                                                   \
    {                                                                                                                              \
      ++failures;                                                                                                                  \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);                                                                  \
    }                                                                                                                              \
  } while (0)

// The real gateway data[] base VMA, so the offsets tested here match the patch tables.
constexpr std::uint64_t gatewayDataBase = 0x1418500B0ULL;

void testRelocatedDataOffset()
{
  using pfix::relocatedDataOffset;

  // Same address -> zero offset.
  CHECK(relocatedDataOffset(gatewayDataBase, gatewayDataBase) == 0);
  // data[]+0x08 (the refcount field the clear-all / releaseAll loop LEAs target).
  CHECK(relocatedDataOffset(0x1418500B8ULL, gatewayDataBase) == 0x8);
  // The gateway OBJECT base sits 0x20 below data[] -> negative offset (hence the preamble page).
  CHECK(relocatedDataOffset(0x141850090ULL, gatewayDataBase) == -0x20);

  // Usable in a constant expression.
  static_assert(relocatedDataOffset(0x1418500B8ULL, 0x1418500B0ULL) == 0x8, "relocatedDataOffset constexpr");
}

void testRelativeDisplacementAndFits()
{
  using pfix::fitsInt32;
  using pfix::relativeDisplacement;

  // jmp rel32 is 5 bytes; a jump to the immediately-following instruction is 0.
  CHECK(relativeDisplacement(0x1000, 0x1005, 5) == 0);
  // Forward jump: target - (from + 5).
  CHECK(relativeDisplacement(0x1000, 0x1100, 5) == 0x100 - 5);
  // Backward jump is negative.
  CHECK(relativeDisplacement(0x2000, 0x1000, 5) == -(0x1000 + 5));
  // lea reg,[rip+disp32] is 7 bytes; a self-relative reference to the next insn is 0.
  CHECK(relativeDisplacement(0x1000, 0x1007, 7) == 0);

  CHECK(fitsInt32(0));
  CHECK(fitsInt32(INT32_MAX));
  CHECK(fitsInt32(INT32_MIN));
  CHECK(!fitsInt32(static_cast<std::int64_t>(INT32_MAX) + 1));
  CHECK(!fitsInt32(static_cast<std::int64_t>(INT32_MIN) - 1));
}

void testSiblingPath()
{
  using pfix::siblingPath;
  char out[64];

  // Windows backslash path: file component swapped, directory (with trailing sep) kept.
  CHECK(siblingPath("C:\\Games\\xgameFinal.exe", "particlefix.log", out, sizeof out));
  CHECK(std::strcmp(out, "C:\\Games\\particlefix.log") == 0);

  // Forward slash separators are recognised too.
  CHECK(siblingPath("/opt/game/version.dll", "particlefix.log", out, sizeof out));
  CHECK(std::strcmp(out, "/opt/game/particlefix.log") == 0);

  // No separator at all -> just the bare file name.
  CHECK(siblingPath("version.dll", "particlefix.log", out, sizeof out));
  CHECK(std::strcmp(out, "particlefix.log") == 0);

  // A path already ending in a separator keeps it and appends the file.
  CHECK(siblingPath("C:\\Games\\", "log.txt", out, sizeof out));
  CHECK(std::strcmp(out, "C:\\Games\\log.txt") == 0);

  // Exact fit: prefix "a\\" (2) + "bc" (2) + NUL (1) = 5 == capacity.
  char tight[5];
  CHECK(siblingPath("a\\z", "bc", tight, sizeof tight));
  CHECK(std::strcmp(tight, "a\\bc") == 0);

  // One byte too small -> refused, no overflow.
  char tooSmall[4];
  CHECK(!siblingPath("a\\z", "bc", tooSmall, sizeof tooSmall));

  // Degenerate arguments are rejected rather than crashing.
  CHECK(!siblingPath("a", "b", out, 0));
  CHECK(!siblingPath(nullptr, "b", out, sizeof out));
  CHECK(!siblingPath("a", nullptr, out, sizeof out));
}

} // namespace

int main()
{
  testRelocatedDataOffset();
  testRelativeDisplacementAndFits();
  testSiblingPath();

  std::printf("%d checks, %d failures\n", checks, failures);
  return failures == 0 ? 0 : 1;
}
