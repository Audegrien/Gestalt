/*
  test_patchset_golden.cpp

  Standalone test
  Host-native golden test of the REAL PatchSet apply path against a fabricated
  in-memory image, asserting the emitted LEA/immediate/trampoline bytes exactly.

  Buffer layout (so every disp32/rel32 stays within int32 reach):
    [ module region (covers all patch-site VMAs) ][ preamble ][ relocated data ][ tramp arena ]
*/

#include "CodeWriter.hpp"
#include "LineLogger.hpp"
#include "ModuleImage.hpp"
#include "PatchSet.hpp"
#include "RelocatedDataArray.hpp"
#include "pfix_config.hpp"
#include "pfix_util.hpp"

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

namespace
{

int failures = 0;
int checks = 0;

#define CHECK(cond)                                                                                                                \
  do                                                                                                                               \
  {                                                                                                                                \
    ++checks;                                                                                                                      \
    if (!(cond))                                                                                                                   \
    {                                                                                                                              \
      ++failures;                                                                                                                  \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);                                                                  \
    }                                                                                                                              \
  } while (0)

namespace cfg = pfix::config;

// ---- Test doubles for the injected interfaces.
class NullLineLogger : public pfix::LineLogger
{
public:
  void writeLine(const char *, ...) override { }
};

// Records the make-executable finalize and performs writes as a bare memcpy.
class BufferCodeWriter : public pfix::CodeWriter
{
public:
  bool writeCode(void *destination, const void *source, std::size_t length) override
  {
    std::memcpy(destination, source, length);
    return true;
  }
  bool makeExecutable(void *address, std::size_t length) override
  {
    madeExecutable = true;
    executableAddress = address;
    executableLength = length;
    return true;
  }
  bool madeExecutable = false;
  void *executableAddress = nullptr;
  std::size_t executableLength = 0;
};

// The lowest patch-site VMA is the serializer immediate at 0x140369F2C; page-align just below it.
constexpr std::uint64_t regionBaseVma = 0x140369000ULL;
// Must cover the highest patch site: the atexit LEA at 0x140F08748 (+7). 0xBA0000 reaches 0x140F09000.
constexpr std::size_t moduleRegionSize = 0xBA0000;

std::int32_t readInt32(const std::uint8_t *at)
{
  std::int32_t value;
  std::memcpy(&value, at, sizeof value);
  return value;
}

std::uint32_t readUInt32(const std::uint8_t *at)
{
  std::uint32_t value;
  std::memcpy(&value, at, sizeof value);
  return value;
}

std::size_t alignUp16(std::size_t value)
{
  return (value + 15) & ~std::size_t{ 15 };
}

// Assert one trampoline: site JMPs into the stub (NOP-padded), stub holds `body` + resume JMP.
// Advances `cursor` past the 16-byte-aligned stub, mirroring PatchSet::emitStub.
void checkTrampoline(const pfix::ModuleImage &image, const pfix::RelocatedDataArray &relocated, const cfg::TrampolinePatch &patch,
                     const std::vector<std::uint8_t> &body, std::size_t &cursor)
{
  std::uint8_t *const arena = relocated.getTrampolineArena();
  std::uint8_t *const stub = arena + cursor;

  // --- stub body bytes ---
  for (std::size_t i = 0; i < body.size(); ++i)
    if (stub[i] != body[i])
    {
      ++failures;
      std::printf("FAIL %s stub body byte %zu: have %02x want %02x\n", patch.description, i, stub[i], body[i]);
    }
  ++checks;

  // --- resume JMP after the body ---
  std::uint8_t *const resumeSite = stub + body.size();
  const std::int32_t expectedResumeRel = static_cast<std::int32_t>(pfix::relativeDisplacement(
      reinterpret_cast<std::uintptr_t>(resumeSite), reinterpret_cast<std::uintptr_t>(image.resolve(patch.resumeVma)), 5));
  CHECK(resumeSite[0] == 0xE9);
  CHECK(readInt32(resumeSite + 1) == expectedResumeRel);

  // --- site JMP into the stub, NOP-padded to patchedLength ---
  std::uint8_t *const site = image.resolve(patch.siteVma);
  const std::int32_t expectedSiteRel = static_cast<std::int32_t>(
      pfix::relativeDisplacement(reinterpret_cast<std::uintptr_t>(site), reinterpret_cast<std::uintptr_t>(stub), 5));
  CHECK(site[0] == 0xE9);
  CHECK(readInt32(site + 1) == expectedSiteRel);
  for (int i = 5; i < patch.patchedLength; ++i)
    CHECK(site[i] == 0x90);

  const std::size_t stubLength = body.size() + 5;
  cursor += alignUp16(stubLength);
}

// Little-endian bytes of the substitute base pointer a stub embeds as its mov reg,imm64 operand.
void appendPointer(std::vector<std::uint8_t> &out, const std::uint8_t *pointer)
{
  std::uint8_t bytes[sizeof pointer];
  std::memcpy(bytes, &pointer, sizeof pointer);
  for (unsigned char byte : bytes)
    out.push_back(byte);
}

} // namespace

int main()
{
  const std::size_t bufferSize = moduleRegionSize + cfg::relocationPreambleBytes + cfg::newDataByteSize + cfg::trampolineArenaBytes;
  std::vector<std::uint8_t> buffer(bufferSize, 0);

  std::uint8_t *const dataBase = buffer.data() + moduleRegionSize + cfg::relocationPreambleBytes;
  std::uint8_t *const trampolineArena = dataBase + cfg::newDataByteSize;

  NullLineLogger nullLogger;
  BufferCodeWriter writer;

  pfix::ModuleImage image;
  image.initializeForTest(buffer.data(), regionBaseVma, nullLogger);
  pfix::RelocatedDataArray relocated;
  relocated.initializeForTest(dataBase, trampolineArena);

  // ---- seed the module region with pristine bytes so verifyOriginalBytes() passes ----
  for (const cfg::LeaRedirect &lea : cfg::leaRedirects)
  {
    std::uint8_t *site = image.resolve(lea.instructionVma);
    std::memcpy(site, lea.opcodePrefix, 3);
    const std::int32_t originalDisp = static_cast<std::int32_t>(static_cast<std::int64_t>(lea.originalTargetVma) -
                                                                static_cast<std::int64_t>(lea.instructionVma + 7));
    std::memcpy(site + 3, &originalDisp, sizeof originalDisp);
  }
  for (const cfg::ImmediatePatch &imm : cfg::immediatePatches)
    std::memcpy(image.resolve(imm.immediateVma), &imm.oldValue, sizeof imm.oldValue);
  const cfg::TrampolinePatch *trampolines[] = { &cfg::dispatcherCase0, &cfg::dispatcherCase1, &cfg::writer };
  for (const cfg::TrampolinePatch *trampoline : trampolines)
    std::memcpy(image.resolve(trampoline->siteVma), trampoline->originalBytes, trampoline->patchedLength);

  // ---- run the real patch engine ----
  pfix::PatchSet patchSet(image, relocated, writer, nullLogger);
  CHECK(patchSet.verifyOriginalBytes());
  CHECK(patchSet.applyAll());
  CHECK(writer.madeExecutable);
  CHECK(writer.executableAddress == trampolineArena);
  CHECK(writer.executableLength == cfg::trampolineArenaBytes);

  // ---- golden: LEA disp32s repointed at the relocated array ----
  for (const cfg::LeaRedirect &lea : cfg::leaRedirects)
  {
    std::uint8_t *site = image.resolve(lea.instructionVma);
    CHECK(site[0] == lea.opcodePrefix[0] && site[1] == lea.opcodePrefix[1] && site[2] == lea.opcodePrefix[2]);
    std::uint8_t *newTarget = relocated.relocatedAddressFor(lea.originalTargetVma);
    const std::int32_t expected = static_cast<std::int32_t>(
        pfix::relativeDisplacement(reinterpret_cast<std::uintptr_t>(site), reinterpret_cast<std::uintptr_t>(newTarget), 7));
    if (readInt32(site + 3) != expected)
    {
      ++failures;
      std::printf("FAIL LEA @%llx disp: have %d want %d (%s)\n", static_cast<unsigned long long>(lea.instructionVma),
                  readInt32(site + 3), expected, lea.description);
    }
    ++checks;
  }

  // ---- golden: immediates raised to the new cap ----
  for (const cfg::ImmediatePatch &imm : cfg::immediatePatches)
  {
    if (readUInt32(image.resolve(imm.immediateVma)) != imm.newValue)
    {
      ++failures;
      std::printf("FAIL IMM @%llx: have %#x want %#x (%s)\n", static_cast<unsigned long long>(imm.immediateVma),
                  readUInt32(image.resolve(imm.immediateVma)), imm.newValue, imm.description);
    }
    ++checks;
  }

  // ---- golden: the three trampoline stubs, byte-for-byte, in install order ----
  std::size_t cursor = 0;

  // dispatcher case0: push rax ; mov rax,base ; add rsi,rax ; pop rax ; mov r8,[rsi]
  std::vector<std::uint8_t> case0Body = { 0x50, 0x48, 0xB8 };
  appendPointer(case0Body, relocated.anchorFor(cfg::dispatcherCase0.baseAnchorOffset));
  for (std::uint8_t byte : { 0x48, 0x01, 0xC6, 0x58, 0x4C, 0x8B, 0x06 })
    case0Body.push_back(byte);
  checkTrampoline(image, relocated, cfg::dispatcherCase0, case0Body, cursor);

  // dispatcher case1: push rcx ; mov rcx,base ; mov edx,[rcx+rax+0x10] ; pop rcx ; cmp edx,-1
  std::vector<std::uint8_t> case1Body = { 0x51, 0x48, 0xB9 };
  appendPointer(case1Body, relocated.anchorFor(cfg::dispatcherCase1.baseAnchorOffset));
  for (std::uint8_t byte : { 0x8B, 0x54, 0x01, 0x10, 0x59, 0x83, 0xFA, 0xFF })
    case1Body.push_back(byte);
  checkTrampoline(image, relocated, cfg::dispatcherCase1, case1Body, cursor);

  // writer: mov r9,base ; mov [rcx+r9+0x24],eax  (r9 intentionally left holding the relocated base)
  std::vector<std::uint8_t> writerBody = { 0x49, 0xB9 };
  appendPointer(writerBody, relocated.anchorFor(cfg::writer.baseAnchorOffset));
  for (std::uint8_t byte : { 0x42, 0x89, 0x44, 0x09, 0x24 })
    writerBody.push_back(byte);
  checkTrampoline(image, relocated, cfg::writer, writerBody, cursor);

  std::printf("%d checks, %d failures\n", checks, failures);
  return failures == 0 ? 0 : 1;
}
