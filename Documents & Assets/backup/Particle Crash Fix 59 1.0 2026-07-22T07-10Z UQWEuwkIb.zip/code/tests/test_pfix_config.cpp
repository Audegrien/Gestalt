/*
  test_pfix_config.cpp

  Standalone test
  Host-native invariant checks over the constexpr patch tables in pfix_config.hpp,
  with per-site diagnostics a static_assert cannot print, tied to the same
  arithmetic helpers the DLL uses.
*/

#include "pfix_config.hpp"
#include "pfix_util.hpp"

#include <cstdint>
#include <cstdio>

namespace
{

int failures = 0;
int checks = 0;

#define CHECK(cond)                                                                                                                \
  do                                                                                                                               \
  {                                                                                                                                \
    ++checks;                                                                                                                      \
    if (!(cond))                                                                                                                   \
    {                                                                                                                              \
      ++failures;                                                                                                                  \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);                                                                  \
    }                                                                                                                              \
  } while (0)

namespace cfg = pfix::config;

// The header's constexpr predicates, re-run at runtime alongside the granular checks below.
void testHeaderInvariants()
{
  CHECK(!cfg::anyPatchSitesOverlap());
  CHECK(cfg::allLeaTargetsInWindow());
  CHECK(cfg::allLeaOpcodesWellFormed());
  CHECK(cfg::allImmediatesRaiseToNewCap());
  CHECK(cfg::allTrampolinesWellFormed());
  CHECK(cfg::immediatesWithOldValue(cfg::originalSlotCount) == 5);
  CHECK(cfg::immediatesWithOldValue(0x3E8) == 1);
}

// Every patched VMA is distinct — printed pairwise so a collision names both offenders.
void testSiteAddressesUnique()
{
  for (std::size_t first = 0; first < cfg::patchSiteCount; ++first)
    for (std::size_t second = first + 1; second < cfg::patchSiteCount; ++second)
    {
      const std::uint64_t startFirst = cfg::patchSiteStart(first);
      const std::uint64_t startSecond = cfg::patchSiteStart(second);
      if (startFirst == startSecond)
      {
        ++failures;
        std::printf("FAIL duplicate patch site %#llx (index %zu and %zu)\n", static_cast<unsigned long long>(startFirst), first,
                    second);
      }
      ++checks;
    }
}

// Each LEA's redirected target maps into the reserved window, and its disp32 (computed via
// pfix_util) reaches from the instruction to the relocated slot at a realistic near-module base.
void testLeaTargetsMapAndReach()
{
  using pfix::fitsInt32;
  using pfix::relativeDisplacement;
  using pfix::relocatedDataOffset;

  // Relocated array ~1.5 GB below the module — inside the ~1.9 GB probe window, so disp32 must fit.
  constexpr std::uint64_t relocatedBase = cfg::preferredImageBase - 0x60000000ULL;

  for (std::size_t i = 0; i < cfg::leaCount; ++i)
  {
    const auto &lea = cfg::leaRedirects[i];
    const std::int64_t offset = relocatedDataOffset(lea.originalTargetVma, cfg::gatewayDataBaseVma);

    // Inside [ -preamble, +dataBytes ).
    CHECK(offset >= -static_cast<std::int64_t>(cfg::relocationPreambleBytes));
    CHECK(offset < static_cast<std::int64_t>(cfg::newDataByteSize));

    // disp32 from `lea reg,[rip+disp32]` (7-byte instruction) to the relocated slot fits.
    const std::uint64_t relocatedTarget = relocatedBase + static_cast<std::uint64_t>(offset);
    const std::int64_t disp = relativeDisplacement(lea.instructionVma, relocatedTarget, 7);
    if (!fitsInt32(disp))
    {
      ++failures;
      std::printf("FAIL LEA %#llx disp32 out of range (%lld)\n", static_cast<unsigned long long>(lea.instructionVma),
                  static_cast<long long>(disp));
    }
    ++checks;
  }
}

// Guard the specific promised values — the CAP GATE, the save ceiling, the per-site anchors.
void testKnownSiteValues()
{
  // The cap gate is one of the immediates and must move 512 -> 4096.
  bool sawCapGate = false;
  for (std::size_t i = 0; i < cfg::immediateCount; ++i)
    if (cfg::immediatePatches[i].immediateVma == cfg::siteCapCompare + 2) // imm32 is 2 bytes into `cmp ecx,imm32`
    {
      sawCapGate = true;
      CHECK(cfg::immediatePatches[i].oldValue == cfg::originalSlotCount);
      CHECK(cfg::immediatePatches[i].newValue == cfg::newSlotCount);
    }
  CHECK(sawCapGate);

  // Exactly one immediate carries the 1000-entry save ceiling.
  bool sawSaveCeiling = false;
  for (std::size_t i = 0; i < cfg::immediateCount; ++i)
    if (cfg::immediatePatches[i].oldValue == 0x3E8)
    {
      sawSaveCeiling = true;
      CHECK(cfg::immediatePatches[i].newValue == cfg::newSlotCount);
    }
  CHECK(sawSaveCeiling);

  // The two dispatcher trampolines anchor at this-== dataBase-0x20; the writer at dataBase-0x10
  // (a -0x20 anchor there would corrupt the name pointer — see pfix_config.hpp).
  CHECK(cfg::dispatcherCase0.baseAnchorOffset == -0x20);
  CHECK(cfg::dispatcherCase1.baseAnchorOffset == -0x20);
  CHECK(cfg::writer.baseAnchorOffset == -0x10);

  // Each trampoline overwrites at least a JMP rel32 and no more than its asserted-original span.
  CHECK(cfg::dispatcherCase0.patchedLength >= 5);
  CHECK(cfg::dispatcherCase1.patchedLength >= 5);
  CHECK(cfg::writer.patchedLength >= 5);
}

} // namespace

int main()
{
  testHeaderInvariants();
  testSiteAddressesUnique();
  testLeaTargetsMapAndReach();
  testKnownSiteValues();

  std::printf("%d checks, %d failures\n", checks, failures);
  return failures == 0 ? 0 : 1;
}
