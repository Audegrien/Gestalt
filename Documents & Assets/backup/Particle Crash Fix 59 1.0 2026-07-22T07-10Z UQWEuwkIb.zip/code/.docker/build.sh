#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DOCKER_DIR="$ROOT/.docker"
IMAGE="particlefix-toolchain:latest"

compose() { ( cd "$DOCKER_DIR" && docker compose "$@" ); }

echo "==> building docker image ($IMAGE) ..."
compose build

# PFIX_VERSION (optional) overrides the CMake project version — CI sets it from the tag.
compose run --rm -e PFIX_VERSION="${PFIX_VERSION:-}" re bash -lc '
    set -e

    echo "==> ParticleFix unit tests"
    rm -rf build-tests
    cmake -S tests -B build-tests >/dev/null
    cmake --build build-tests --parallel >/dev/null
    ctest --test-dir build-tests --output-on-failure

    echo "==> ParticleFix release build"
    rm -rf build
    ver_arg=""
    if [ -n "${PFIX_VERSION:-}" ]; then
        ver_arg="-DPFIX_VERSION=${PFIX_VERSION}"
        echo "    (version overridden to ${PFIX_VERSION})"
    fi
    cmake -S src --preset mingw $ver_arg >/dev/null
    cmake --build build --parallel --target release
'
echo
echo "==> release archive(s) in dist/:"
( cd "$ROOT/dist" && ls -1 ParticleFix-*.zip 2>/dev/null | while read -r z; do
    sha256sum "$z"; done ) | sed 's/^/    /' || true
echo "==> done."
