/*
  LineLogger.hpp

  Interface header (implemented by the LoggerLineSink adapter in Logger.hpp)
  Host-clean logging interface the patch engine logs through, so it compiles free
  of <windows.h>.
*/

#ifndef PFIX_LINE_LOGGER_HPP
#define PFIX_LINE_LOGGER_HPP

namespace pfix
{

class LineLogger
{
public:
  // printf-style, newline-terminated, serialized — same contract as Logger::writeLine.
  virtual void writeLine(const char *format, ...) = 0;

protected:
  // Non-virtual protected: implementations are never destroyed through this interface.
  ~LineLogger() = default;
};

} // namespace pfix

#endif // PFIX_LINE_LOGGER_HPP
