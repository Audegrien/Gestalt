/*
  CapMonitor.cpp

  Implementation file for CapMonitor.hpp
  A daemon thread polling the gateway's live-slot count; logs the current count once a minute.
*/

#include "CapMonitor.hpp"

#include "Logger.hpp"
#include "ModuleImage.hpp"
#include "pfix_config.hpp"

namespace pfix
{

namespace cfg = config;

void CapMonitor::start(Logger &log, const ModuleImage &image)
{
  logger = &log;
  liveCount = reinterpret_cast<const volatile std::uint32_t *>(image.resolve(cfg::liveCountVma));

  HANDLE thread = CreateThread(nullptr, 0, &CapMonitor::threadMain, this, 0, nullptr);
  if (thread)
  {
    CloseHandle(thread); // fire-and-forget daemon, reaped by the OS at exit
    logger->writeLine("[pfix] cap monitor watching live slot count @ %p - reports the current count every %lu s", liveCount,
                      pollIntervalMs / 1000);
  }
  else
  {
    logger->writeLine("[pfix] WARN: CreateThread(cap monitor) err=%lu - no exceed-cap announcement this run", GetLastError());
  }
}

DWORD WINAPI CapMonitor::threadMain(LPVOID parameter)
{
  static_cast<CapMonitor *>(parameter)->pollLoop();
  return 0;
}

void CapMonitor::pollLoop()
{
  for (;;)
  {
    Sleep(pollIntervalMs);

    const std::uint32_t current = *liveCount;
    // A wild value means the wrong address or a moved field; flag it rather than reporting garbage.
    if (current > cfg::newSlotCount)
    {
      logger->writeLine("[pfix] cap monitor: implausible live count %u (> new cap %u) - counter "
                        "field may have moved in this build; ignoring this sample.",
                        current, cfg::newSlotCount);
      continue;
    }

    logger->updateLine("[pfix] live particle slots in use: %u/%u", current, cfg::newSlotCount);
  }
}

} // namespace pfix
