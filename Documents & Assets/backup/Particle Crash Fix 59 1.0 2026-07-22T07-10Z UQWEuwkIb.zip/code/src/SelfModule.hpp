/*
  SelfModule.hpp

  Include file for SelfModule.cpp
  Locate our own loaded module (version.dll) via an anchor symbol, and read a PE
  image's SizeOfImage.
*/

#ifndef PFIX_SELF_MODULE_HPP
#define PFIX_SELF_MODULE_HPP

#include <cstddef>
#include <windows.h>

namespace pfix
{

// Handle of the module this code is linked into; nullptr only if the lookup fails.
HMODULE getSelfModule();

// SizeOfImage from a loaded module's PE headers; 0 if null or the headers don't validate.
std::size_t imageSizeOf(const void *moduleBase);

} // namespace pfix

#endif // PFIX_SELF_MODULE_HPP
