/*
  ModuleImage.hpp

  Include file for ModuleImage.cpp and ModuleImage.win32.cpp
  The loaded target binary as an object: the ASLR slide plus resolve/read/verify
  helpers. The host-clean read/verify logic lives in ModuleImage.cpp; locating the
  module and computing the slide (the one Win32-dependent method) in
  ModuleImage.win32.cpp.
*/

#ifndef PFIX_MODULE_IMAGE_HPP
#define PFIX_MODULE_IMAGE_HPP

#include <cstdint>

namespace pfix
{

class LineLogger;

class ModuleImage
{
public:
  ModuleImage() = default;
  ModuleImage(const ModuleImage &) = delete;
  ModuleImage &operator=(const ModuleImage &) = delete;

  // Locate the module and compute the slide against the config's preferred base; false if not found.
  bool initialize(const char *name, std::uint64_t preferredBase, LineLogger &log);

  // Test seam: map an arbitrary VMA region onto a caller-owned buffer; host-usable.
  void initializeForTest(std::uint8_t *liveBase, std::uint64_t baseVma, LineLogger &log)
  {
    moduleBase = liveBase;
    imageSlide = reinterpret_cast<std::intptr_t>(liveBase) - static_cast<std::intptr_t>(baseVma);
    logger = &log;
  }

  // Live address of a static VMA under the current slide.
  std::uint8_t *resolve(std::uint64_t staticVma) const
  {
    return reinterpret_cast<std::uint8_t *>(static_cast<std::uintptr_t>(staticVma) + imageSlide);
  }

  std::uint8_t *getModuleBase() const { return moduleBase; }
  std::intptr_t getImageSlide() const { return imageSlide; }

  // Compare `count` bytes at a static VMA against `expected`; log the first mismatch.
  bool expectBytes(std::uint64_t staticVma, const std::uint8_t *expected, int count) const;

  // Read the little-endian disp32 that follows a 3-byte LEA opcode/modrm.
  std::int32_t readLeaDisplacement(std::uint64_t staticVma) const;

  // Read a little-endian u32 at a static VMA.
  std::uint32_t readUInt32(std::uint64_t staticVma) const;

private:
  std::uint8_t *moduleBase = nullptr;
  std::intptr_t imageSlide = 0;
  LineLogger *logger = nullptr;
};

} // namespace pfix

#endif // PFIX_MODULE_IMAGE_HPP
