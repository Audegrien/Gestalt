# Script-mode (cmake -P) helper: emit the code/ source folder + SHA256SUMS.txt into
# PFIX_STAGE_DIR. Runs after the DLL is built so the checksums cover the shipped bytes.
# Required cache vars: PFIX_VERSION PFIX_REPO_ROOT PFIX_DLL PFIX_README PFIX_STAGE_DIR.
cmake_minimum_required(VERSION 3.28)

foreach(_v PFIX_VERSION PFIX_REPO_ROOT PFIX_DLL PFIX_README PFIX_STAGE_DIR)
    if(NOT DEFINED ${_v})
        message(FATAL_ERROR "stage_release.cmake: -D${_v}=... is required")
    endif()
endforeach()
if(NOT EXISTS "${PFIX_DLL}")
    message(FATAL_ERROR "stage_release.cmake: '${PFIX_DLL}' not found — build the version target first")
endif()

set(_codedir "${PFIX_STAGE_DIR}/code")

file(REMOVE_RECURSE "${PFIX_STAGE_DIR}")
file(MAKE_DIRECTORY "${_codedir}")

# The public file set is single-sourced from public-manifest.txt so the release code
# folder and the public git mirror (.gitea/sync-public-mirror.sh) never drift.
set(_manifest "${PFIX_REPO_ROOT}/public-manifest.txt")
if(NOT EXISTS "${_manifest}")
    message(FATAL_ERROR "stage_release.cmake: public manifest '${_manifest}' not found")
endif()
file(STRINGS "${_manifest}" _manifest_lines ENCODING UTF-8)
foreach(_line ${_manifest_lines})
    string(STRIP "${_line}" _item)
    if(_item STREQUAL "" OR _item MATCHES "^#")
        continue()
    endif()
    if(EXISTS "${PFIX_REPO_ROOT}/${_item}")
        get_filename_component(_dir "${_item}" DIRECTORY)
        file(COPY "${PFIX_REPO_ROOT}/${_item}" DESTINATION "${_codedir}/${_dir}")
    endif()
endforeach()

set(_sums "")
macro(_pfix_add_sum _path _archive_name)
    file(SHA256 "${_path}" _h)
    string(APPEND _sums "${_h}  ${_archive_name}\n")
endmacro()
_pfix_add_sum("${PFIX_DLL}" "version.dll")
_pfix_add_sum("${PFIX_README}" "README.md")
file(WRITE "${PFIX_STAGE_DIR}/SHA256SUMS.txt" "${_sums}")

message(STATUS "[stage] code/ folder + SHA256SUMS.txt -> ${PFIX_STAGE_DIR}")
