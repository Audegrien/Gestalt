/*
  PatchSet.hpp

  Include file for PatchSet.cpp
  Verifies and applies the three kinds of edit (LEA redirects, immediate bumps,
  trampolines). Host-clean byte-assembly: memory and logging go through injected
  interfaces, so the encoding logic is unit-testable.
*/

#ifndef PFIX_PATCH_SET_HPP
#define PFIX_PATCH_SET_HPP

#include <cstdint>

#include "pfix_config.hpp"

namespace pfix
{

class CodeWriter;
class LineLogger;
class ModuleImage;
class RelocatedDataArray;

class PatchSet
{
public:
  PatchSet(const ModuleImage &img, const RelocatedDataArray &reloc, CodeWriter &codeWriter, LineLogger &log)
      : image(img),
        relocated(reloc),
        writer(codeWriter),
        logger(log)
  { }

  PatchSet(const PatchSet &) = delete;
  PatchSet &operator=(const PatchSet &) = delete;

  // Assert original bytes at every site; no writes.
  bool verifyOriginalBytes() const;

  // Perform all writes; false if any write fails, leaving state possibly inconsistent.
  bool applyAll() const;

private:
  bool applyLeaRedirects() const;
  bool applyImmediatePatches() const;
  bool applyTrampolines() const;

  // The three bespoke stubs; each bounds-checks the arena before writing, then calls emitStub().
  bool installDispatcherCase0Stub(std::uint8_t *&arenaCursor, const std::uint8_t *arenaEnd) const;
  bool installDispatcherCase1Stub(std::uint8_t *&arenaCursor, const std::uint8_t *arenaEnd) const;
  bool installWriterStub(std::uint8_t *&arenaCursor, const std::uint8_t *arenaEnd) const;

  // Shared trampoline tail: append the resume JMP, overwrite the site with a JMP into the stub.
  bool emitStub(const config::TrampolinePatch &patch, std::uint8_t *&arenaCursor, int bodyLength) const;

  const ModuleImage &image;
  const RelocatedDataArray &relocated;
  CodeWriter &writer;
  LineLogger &logger;
};

} // namespace pfix

#endif // PFIX_PATCH_SET_HPP
