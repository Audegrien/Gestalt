/*
  SelfModule.cpp

  Implementation file for SelfModule.hpp
  Locate our own loaded module (version.dll) via an anchor symbol, and read a PE
  image's SizeOfImage.
*/

#include "SelfModule.hpp"

#include <cstdint>

namespace pfix
{

namespace
{
// A symbol inside our own DLL, so GetModuleHandleEx(FROM_ADDRESS) on it resolves to our module.
void selfModuleAnchor() { }
} // namespace

HMODULE getSelfModule()
{
  HMODULE self = nullptr;
  if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                          reinterpret_cast<LPCSTR>(&selfModuleAnchor), &self))
    return nullptr;
  return self;
}

std::size_t imageSizeOf(const void *moduleBase)
{
  if (!moduleBase)
    return 0;
  const auto *base = static_cast<const std::uint8_t *>(moduleBase);
  const auto *dos = reinterpret_cast<const IMAGE_DOS_HEADER *>(base);
  if (dos->e_magic != IMAGE_DOS_SIGNATURE)
    return 0;
  const auto *nt = reinterpret_cast<const IMAGE_NT_HEADERS *>(base + dos->e_lfanew);
  if (nt->Signature != IMAGE_NT_SIGNATURE)
    return 0;
  return nt->OptionalHeader.SizeOfImage;
}

} // namespace pfix
