/*
  CrashLogger.hpp

  Include file for CrashLogger.cpp
  Crash reporter that logs the faulting Rip and more (as static VMAs) then lets WER run.
  Keeps its SEH filter undisplaceable by hooking the game's SetUnhandledExceptionFilter import.
*/

#ifndef PFIX_CRASH_LOGGER_HPP
#define PFIX_CRASH_LOGGER_HPP

#include <cstddef>
#include <cstdint>
#include <windows.h>

namespace pfix
{

class Logger;

class CrashLogger
{
public:
  CrashLogger() = default;
  CrashLogger(const CrashLogger &) = delete;
  CrashLogger &operator=(const CrashLogger &) = delete;

  // Register the filter; call once from DllMain. `gameBase`/`imageSlide` come from ModuleImage.
  void install(Logger &logger, std::uint8_t *gameBase, std::intptr_t imageSlide);

private:
  // Last-chance SEH filter; the WINAPI thunk forwards here via activeInstance.
  LONG handleException(EXCEPTION_POINTERS *exceptionInfo);
  static LONG WINAPI filterThunk(EXCEPTION_POINTERS *exceptionInfo);

  // Repoint the game's SetUnhandledExceptionFilter import at our stub so it can't displace us.
  void protectFilterFromDisplacement();
  // Import replacement: record the game's would-be filter as our chain target, keep ours installed.
  static LPTOP_LEVEL_EXCEPTION_FILTER WINAPI hookedSetFilter(LPTOP_LEVEL_EXCEPTION_FILTER wanted);
  // Find the game IAT slot holding `targetFunction`, or nullptr if this module doesn't import it.
  static void **findGameImportSlot(std::uint8_t *base, void *targetFunction);

  // Emit the full crash report; the reentrancy guard keeps a fault while logging from recursing.
  void writeReport(const EXCEPTION_RECORD *record, const CONTEXT *context);

  // Log one code address as raw / module+offset / static VMA, tagging which module it lands in.
  void logCodeAddress(const char *label, std::uintptr_t address) const;

  // Best-effort call chain: scan committed stack for return addresses into the game image.
  void logStackReturnAddresses(std::uintptr_t stackPointer) const;

  static CrashLogger *activeInstance;

  Logger *logger = nullptr;
  // The filter we chain to on a real crash; updated as the game (re)sets its own via our hook.
  LPTOP_LEVEL_EXCEPTION_FILTER chainedFilter = nullptr;
  std::uint8_t *gameBase = nullptr;
  std::size_t gameSize = 0;
  std::intptr_t imageSlide = 0;
  std::uint8_t *selfBase = nullptr;
  std::size_t selfSize = 0;
  volatile LONG handling = 0;
};

} // namespace pfix

#endif // PFIX_CRASH_LOGGER_HPP
