/*
  ModuleImage.cpp

  Implementation file for ModuleImage.hpp
  The loaded target binary as an object: the ASLR slide plus resolve/read/verify
  helpers. The host-clean read/verify logic lives in ModuleImage.cpp; locating the
  module and computing the slide (the one Win32-dependent method) in
  ModuleImage.win32.cpp.
*/

#include "ModuleImage.hpp"

#include <cstring>

#include "LineLogger.hpp"

namespace pfix
{

bool ModuleImage::expectBytes(std::uint64_t staticVma, const std::uint8_t *expected, int count) const
{
  const std::uint8_t *actual = resolve(staticVma);
  for (int i = 0; i < count; i++)
  {
    if (actual[i] != expected[i])
    {
      if (logger)
      {
        logger->writeLine("[pfix] MISMATCH @%llx byte%d: have %02x want %02x", static_cast<unsigned long long>(staticVma), i,
                          actual[i], expected[i]);
      }
      return false;
    }
  }
  return true;
}

std::int32_t ModuleImage::readLeaDisplacement(std::uint64_t staticVma) const
{
  std::int32_t displacement;
  std::memcpy(&displacement, resolve(staticVma) + 3, sizeof displacement);
  return displacement;
}

std::uint32_t ModuleImage::readUInt32(std::uint64_t staticVma) const
{
  std::uint32_t value;
  std::memcpy(&value, resolve(staticVma), sizeof value);
  return value;
}

} // namespace pfix
