/*
  RelocatedDataArray.win32.cpp

  Implementation file for RelocatedDataArray.hpp
  Owns the external data[4096] the gateway is redirected onto, plus the trampoline
  arena. Reserves the near-module region (VirtualAlloc within +/-2GB, so disp32/rel32
  reach it) and fills it.

  Single reservation:
      [ preamble 0x1000 ][ relocated data (newDataByteSize) ][ trampoline arena 0x1000 ]
                         ^ dataBase (page-aligned)           ^ getTrampolineArena()
*/

#include "RelocatedDataArray.hpp"

#include <cstring>
#include <windows.h>

#include "Logger.hpp"
#include "ModuleImage.hpp"
#include "pfix_config.hpp"

namespace pfix
{

// Preamble reserved below dataBase; single-owned in the config.
constexpr std::size_t preambleBytes = config::relocationPreambleBytes;

namespace
{
// Reserve+commit RW memory within +/-2GB of `moduleBase` so disp32/rel32 can reach it.
std::uint8_t *allocateNearModule(std::uint8_t *moduleBase, std::size_t size, DWORD protection)
{
  SYSTEM_INFO systemInfo;
  GetSystemInfo(&systemInfo);
  const std::uintptr_t granularity = systemInfo.dwAllocationGranularity;
  const std::uintptr_t base = reinterpret_cast<std::uintptr_t>(moduleBase);
  const std::size_t rounded = (size + granularity - 1) & ~(granularity - 1);

  // Probe outward from the module, staying inside a ~1.9GB window on each side so rel32 reaches.
  for (std::uintptr_t offset = granularity; offset < 0x78000000ULL; offset += 0x100000ULL)
  {
    const std::uintptr_t candidates[2] = { base - offset, base + offset };
    for (std::uintptr_t candidate : candidates)
    {
      const std::uintptr_t address = candidate & ~(granularity - 1);
      if (address < 0x10000ULL)
        continue;
      void *reserved = VirtualAlloc(reinterpret_cast<void *>(address), rounded, MEM_RESERVE | MEM_COMMIT, protection);
      if (reserved)
        return reinterpret_cast<std::uint8_t *>(reserved);
    }
  }
  return nullptr;
}
} // namespace

bool RelocatedDataArray::allocate(const ModuleImage &image, Logger &logger)
{
  namespace cfg = config;

  const std::size_t regionBytes = preambleBytes + cfg::newDataByteSize + cfg::trampolineArenaBytes;
  std::uint8_t *region = allocateNearModule(image.getModuleBase(), regionBytes, PAGE_READWRITE);
  if (!region)
  {
    logger.writeLine("[pfix] ABORT: allocateNearModule(%llu) failed - no free region "
                     "within +/-2GB",
                     static_cast<unsigned long long>(regionBytes));
    return false;
  }

  dataBase = region + preambleBytes; // page-aligned; -0x20 valid
  trampolineArena = region + preambleBytes + cfg::newDataByteSize;

  std::memset(dataBase, 0, cfg::newDataByteSize); // all slots free (in-use flag = 0)

  // Carry across any already-constructed entries; normally a no-op (count is 0 this early).
  const std::uint8_t *oldData = image.resolve(cfg::gatewayDataBaseVma);
  std::memcpy(dataBase, oldData, static_cast<std::size_t>(cfg::originalSlotCount) * cfg::entrySize);

  logger.writeLine("[pfix] relocated data=%p (%u slots, %#llx bytes)  tramp=%p", dataBase, cfg::newSlotCount,
                   static_cast<unsigned long long>(cfg::newDataByteSize), trampolineArena);
  return true;
}

} // namespace pfix
