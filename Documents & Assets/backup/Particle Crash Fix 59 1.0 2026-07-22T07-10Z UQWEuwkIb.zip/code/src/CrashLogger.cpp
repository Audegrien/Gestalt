/*
  CrashLogger.cpp

  Implementation file for CrashLogger.hpp
  Crash reporter that logs the faulting Rip and more (as static VMAs) then lets WER run.
  Keeps its SEH filter undisplaceable by hooking the game's SetUnhandledExceptionFilter import.
*/

#include "CrashLogger.hpp"

#include "Logger.hpp"
#include "SelfModule.hpp"
#include "pfix_config.hpp"

namespace pfix
{

CrashLogger *CrashLogger::activeInstance = nullptr;

namespace
{

const char *exceptionName(DWORD code)
{
  switch (code)
  {
    case EXCEPTION_ACCESS_VIOLATION:
      return "ACCESS_VIOLATION";
    case EXCEPTION_IN_PAGE_ERROR:
      return "IN_PAGE_ERROR";
    case EXCEPTION_ILLEGAL_INSTRUCTION:
      return "ILLEGAL_INSTRUCTION";
    case EXCEPTION_PRIV_INSTRUCTION:
      return "PRIV_INSTRUCTION";
    case EXCEPTION_STACK_OVERFLOW:
      return "STACK_OVERFLOW";
    case EXCEPTION_BREAKPOINT:
      return "BREAKPOINT (int3 assert)";
    case EXCEPTION_INT_DIVIDE_BY_ZERO:
      return "INT_DIVIDE_BY_ZERO";
    case EXCEPTION_INT_OVERFLOW:
      return "INT_OVERFLOW";
    case EXCEPTION_DATATYPE_MISALIGNMENT:
      return "DATATYPE_MISALIGNMENT";
    case EXCEPTION_FLT_DIVIDE_BY_ZERO:
      return "FLT_DIVIDE_BY_ZERO";
    case EXCEPTION_FLT_INVALID_OPERATION:
      return "FLT_INVALID_OPERATION";
    default:
      return "OTHER";
  }
}

} // namespace

void CrashLogger::install(Logger &log, std::uint8_t *base, std::intptr_t slide)
{
  logger = &log;
  gameBase = base;
  gameSize = imageSizeOf(base);
  imageSlide = slide;

  if (HMODULE self = getSelfModule())
  {
    selfBase = reinterpret_cast<std::uint8_t *>(self);
    selfSize = imageSizeOf(selfBase);
  }

  activeInstance = this;
  chainedFilter = SetUnhandledExceptionFilter(&CrashLogger::filterThunk);
  logger->writeLine("[pfix] crash logger armed - game image %p +%#llx, slide %llx", gameBase,
                    static_cast<unsigned long long>(gameSize), static_cast<unsigned long long>(imageSlide));

  // Runs in DllMain, before the CRT startup that would otherwise overwrite the global filter slot.
  protectFilterFromDisplacement();
}

void CrashLogger::protectFilterFromDisplacement()
{
  void *real = reinterpret_cast<void *>(GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "SetUnhandledExceptionFilter"));
  if (!real)
    return;

  void **slot = findGameImportSlot(gameBase, real);
  if (!slot)
  {
    logger->writeLine("[pfix] WARN: SetUnhandledExceptionFilter import not found - crash filter stays displaceable");
    return;
  }

  DWORD previousProtection;
  if (VirtualProtect(slot, sizeof(void *), PAGE_READWRITE, &previousProtection))
  {
    *slot = reinterpret_cast<void *>(&CrashLogger::hookedSetFilter);
    VirtualProtect(slot, sizeof(void *), previousProtection, &previousProtection);
    logger->writeLine("[pfix] crash filter pinned - SetUnhandledExceptionFilter import redirected @ %p", slot);
  }
  else
  {
    logger->writeLine("[pfix] WARN: could not unprotect the import slot (err=%lu) - filter stays displaceable", GetLastError());
  }
}

LPTOP_LEVEL_EXCEPTION_FILTER WINAPI CrashLogger::hookedSetFilter(LPTOP_LEVEL_EXCEPTION_FILTER wanted)
{
  CrashLogger *self = activeInstance;
  if (!self)
    return nullptr;
  // Swallow the call: remember what the game wanted (we chain to it) but leave our filter in the slot.
  return reinterpret_cast<LPTOP_LEVEL_EXCEPTION_FILTER>(
      InterlockedExchangePointer(reinterpret_cast<void *volatile *>(&self->chainedFilter), reinterpret_cast<void *>(wanted)));
}

void **CrashLogger::findGameImportSlot(std::uint8_t *base, void *targetFunction)
{
  auto dos = reinterpret_cast<const IMAGE_DOS_HEADER *>(base);
  if (dos->e_magic != IMAGE_DOS_SIGNATURE)
    return nullptr;
  auto nt = reinterpret_cast<const IMAGE_NT_HEADERS *>(base + dos->e_lfanew);
  if (nt->Signature != IMAGE_NT_SIGNATURE)
    return nullptr;

  const IMAGE_DATA_DIRECTORY &dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
  if (!dir.VirtualAddress || !dir.Size)
    return nullptr;

  // The loader has resolved every IAT slot to the same address GetProcAddress returns, so match by
  // value across all descriptors' bound thunks - no name parsing, and correct for bound imports.
  for (auto desc = reinterpret_cast<const IMAGE_IMPORT_DESCRIPTOR *>(base + dir.VirtualAddress); desc->Name; ++desc)
    for (auto thunk = reinterpret_cast<IMAGE_THUNK_DATA *>(base + desc->FirstThunk); thunk->u1.Function; ++thunk)
      if (reinterpret_cast<void *>(thunk->u1.Function) == targetFunction)
        return reinterpret_cast<void **>(&thunk->u1.Function);

  return nullptr;
}

LONG WINAPI CrashLogger::filterThunk(EXCEPTION_POINTERS *exceptionInfo)
{
  CrashLogger *self = activeInstance;
  if (!self)
    return EXCEPTION_CONTINUE_SEARCH;
  return self->handleException(exceptionInfo);
}

void CrashLogger::logCodeAddress(const char *label, std::uintptr_t address) const
{
  const auto gameBaseAddr = reinterpret_cast<std::uintptr_t>(gameBase);
  const auto selfBaseAddr = reinterpret_cast<std::uintptr_t>(selfBase);

  if (gameBaseAddr && address >= gameBaseAddr && address < gameBaseAddr + gameSize)
  {
    logger->writeLine("[pfix]   %s=%016llx  xgameFinal.exe+%#llx  static VMA %#llx", label,
                      static_cast<unsigned long long>(address), static_cast<unsigned long long>(address - gameBaseAddr),
                      static_cast<unsigned long long>(address - imageSlide));
  }
  else if (selfBaseAddr && address >= selfBaseAddr && address < selfBaseAddr + selfSize)
  {
    logger->writeLine("[pfix]   %s=%016llx  version.dll+%#llx  (** inside ParticleFix **)", label,
                      static_cast<unsigned long long>(address), static_cast<unsigned long long>(address - selfBaseAddr));
  }
  else
  {
    logger->writeLine("[pfix]   %s=%016llx  (outside game image - system/other module)", label,
                      static_cast<unsigned long long>(address));
  }
}

void CrashLogger::logStackReturnAddresses(std::uintptr_t stackPointer) const
{
  if (!stackPointer || !gameBase)
    return;

  // Bound the scan to the thread's committed stack so a read can never fault off the end.
  ULONG_PTR low = 0, high = 0;
  GetCurrentThreadStackLimits(&low, &high);
  if (stackPointer < low)
    stackPointer = low;

  logger->writeLine("[pfix]   stack scan for game-code return addresses (top-down):");
  const auto gameBaseAddr = reinterpret_cast<std::uintptr_t>(gameBase);
  int found = 0;
  for (std::uintptr_t stackAddr = (stackPointer + 7) & ~std::uintptr_t{ 7 }; stackAddr + sizeof(void *) <= high && found < 24;
       stackAddr += sizeof(void *))
  {
    const std::uintptr_t value = *reinterpret_cast<const std::uintptr_t *>(stackAddr);
    if (value >= gameBaseAddr && value < gameBaseAddr + gameSize)
    {
      logger->writeLine("[pfix]     [rsp+%#llx] static VMA %#llx", static_cast<unsigned long long>(stackAddr - stackPointer),
                        static_cast<unsigned long long>(value - imageSlide));
      ++found;
    }
  }
  if (found == 0)
    logger->writeLine("[pfix]     (none found)");
}

LONG CrashLogger::handleException(EXCEPTION_POINTERS *exceptionInfo)
{
  // Last-chance filter: log once (a fault while logging must not recurse), then chain to the game's
  // filter (tracked through our hook) so WER still runs.
  if (logger && exceptionInfo && exceptionInfo->ExceptionRecord && exceptionInfo->ContextRecord &&
      InterlockedExchange(&handling, 1) == 0)
  {
    writeReport(exceptionInfo->ExceptionRecord, exceptionInfo->ContextRecord);
    InterlockedExchange(&handling, 0);
  }
  return chainedFilter ? chainedFilter(exceptionInfo) : EXCEPTION_CONTINUE_SEARCH;
}

void CrashLogger::writeReport(const EXCEPTION_RECORD *record, const CONTEXT *context)
{
  logger->section("ParticleFix - CRASH");
  logger->writeLine("[pfix] unhandled exception %#lx (%s) flags=%#lx", record->ExceptionCode, exceptionName(record->ExceptionCode),
                    record->ExceptionFlags);

  logCodeAddress("rip", static_cast<std::uintptr_t>(context->Rip));

  if ((record->ExceptionCode == EXCEPTION_ACCESS_VIOLATION || record->ExceptionCode == EXCEPTION_IN_PAGE_ERROR) &&
      record->NumberParameters >= 2)
  {
    const ULONG_PTR operation = record->ExceptionInformation[0];
    const char *verb = operation == 0 ? "read" : operation == 1 ? "write" : "execute";
    logger->writeLine("[pfix]   fault: %s at %#llx", verb, static_cast<unsigned long long>(record->ExceptionInformation[1]));
  }

  logger->writeLine("[pfix]   rax=%016llx rbx=%016llx rcx=%016llx rdx=%016llx", static_cast<unsigned long long>(context->Rax),
                    static_cast<unsigned long long>(context->Rbx), static_cast<unsigned long long>(context->Rcx),
                    static_cast<unsigned long long>(context->Rdx));
  logger->writeLine("[pfix]   rsi=%016llx rdi=%016llx rbp=%016llx rsp=%016llx", static_cast<unsigned long long>(context->Rsi),
                    static_cast<unsigned long long>(context->Rdi), static_cast<unsigned long long>(context->Rbp),
                    static_cast<unsigned long long>(context->Rsp));
  logger->writeLine("[pfix]   r8 =%016llx r9 =%016llx r10=%016llx r11=%016llx", static_cast<unsigned long long>(context->R8),
                    static_cast<unsigned long long>(context->R9), static_cast<unsigned long long>(context->R10),
                    static_cast<unsigned long long>(context->R11));
  logger->writeLine("[pfix]   r12=%016llx r13=%016llx r14=%016llx r15=%016llx", static_cast<unsigned long long>(context->R12),
                    static_cast<unsigned long long>(context->R13), static_cast<unsigned long long>(context->R14),
                    static_cast<unsigned long long>(context->R15));

  logStackReturnAddresses(static_cast<std::uintptr_t>(context->Rsp));

  logger->writeLine("[pfix] end crash report; the exception continues to the default handler. "
                    "Please attach the crash log from the logs folder to reports.");
  logger->rule();

  // Retain this run's log under a timestamped name before the next launch overwrites the live log.
  logger->preserveAsCrashLog(config::crashLogStem, config::crashLogExt);
}

} // namespace pfix
