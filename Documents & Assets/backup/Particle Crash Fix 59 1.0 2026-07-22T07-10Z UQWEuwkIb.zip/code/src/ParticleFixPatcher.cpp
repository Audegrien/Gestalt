/*
  ParticleFixPatcher.cpp

  Implementation file for ParticleFixPatcher.hpp
  Top-level orchestrator: owns the collaborators and runs the whole patch set
  synchronously from DllMain, where every operation is loader-lock-safe.
*/

#include "ParticleFixPatcher.hpp"

#include "PatchSet.hpp"
#include "Win32CodeWriter.hpp"
#include "pfix_config.hpp"

namespace pfix
{

namespace cfg = config;

int ParticleFixPatcher::apply()
{
  logger.initialize(cfg::logDirName, cfg::liveLogName);
  logger.section("ParticleFix - Patch Initialization");

  // Stack-built adapters bridging the concrete collaborators to the host-clean patch-engine interfaces.
  LoggerLineSink logSink(logger);
  Win32CodeWriter codeWriter;

  if (!image.initialize(cfg::moduleName, cfg::preferredImageBase, logSink))
  {
    logger.writeLine("[pfix] ABORT: target module not found in-process - cannot locate xgameFinal.exe.");
    return ApplyAbortedSafe; // nothing written yet
  }
  logger.writeLine("[pfix] array loaded - data-only relocation resizing cap from %u -> %u: module=%p slide=%llx",
                   cfg::originalSlotCount, cfg::newSlotCount, image.getModuleBase(),
                   static_cast<unsigned long long>(image.getImageSlide()));

  // Arm the crash reporter first, so any later fault lands in the log with a static VMA.
  crashLogger.install(logger, image.getModuleBase(), image.getImageSlide());

  // Safe to build before the array is allocated: verification touches only the module image.
  PatchSet patchSet(image, relocatedArray, codeWriter, logSink);

  if (!patchSet.verifyOriginalBytes())
  {
    logger.writeLine("[pfix] ABORT: pre-patch verification failed - NO changes made. Wrong "
                     "exe build? Deploy the pristine binary and re-check the patch "
                     "offsets.");
    return ApplyAbortedSafe; // verified nothing; game code untouched
  }

  if (!relocatedArray.allocate(image, logger))
    return ApplyAbortedSafe; // allocate() already logged; no game-code write happened

  if (!patchSet.applyAll())
  {
    logger.writeLine("[pfix] ABORT: a patch write failed mid-set - game code is now "
                     "HALF-PATCHED and unsafe to run. Remove version.dll from the game "
                     "folder and relaunch (or re-deploy the pristine exe).");
    return ApplyAbortedInconsistent;
  }

  // Optional safety net over the now-dead old in-object array.
#if PFIX_ENABLE_VERIFICATION_GUARD
  std::uint8_t *oldDataLow = image.resolve(cfg::gatewayDataBaseVma);
  std::uint8_t *oldDataHigh = oldDataLow + static_cast<std::size_t>(cfg::originalSlotCount) * cfg::entrySize;
  guard.initialize(logger);
  guard.arm(oldDataLow, oldDataHigh, image.getImageSlide());
  logger.writeLine("[pfix] verification guard armed as a permanent safety net - any UNREDIRECTED accessor is logged");
#endif

  logger.writeLine("[pfix] applied: %u leas + %u imms + %u trampolines", static_cast<unsigned>(cfg::leaCount),
                   static_cast<unsigned>(cfg::immediateCount), static_cast<unsigned>(cfg::trampolineCount));
  logger.writeLine("[pfix] patch applied successfully!");

  // Live-status section: the monitor refreshes a running slot count as usage passes the old cap.
  logger.section("ParticleFix - Live Status");
  capMonitor.start(logger, image);
  return ApplyOk;
}

} // namespace pfix

// One process-lifetime instance; trivially constructed, so nothing runs until apply().
namespace
{
pfix::ParticleFixPatcher particleFixPatcher;
} // namespace

extern "C" int pfix_apply(void)
{
  return particleFixPatcher.apply();
}
