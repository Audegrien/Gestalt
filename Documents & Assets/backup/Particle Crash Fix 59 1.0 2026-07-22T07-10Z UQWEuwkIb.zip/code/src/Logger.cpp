/*
  Logger.cpp

  Implementation file for Logger.hpp
  Allocation-free, critical-section-guarded line logger, safe inside a fault
  handler: formats to a stack buffer and WriteFile()s (no heap allocation).
*/

#include "Logger.hpp"

#include <cstdarg>
#include <cstdio>

#include "SelfModule.hpp"
#include "pfix_util.hpp"

namespace pfix
{

namespace
{
constexpr int bannerInner = 56; // characters between the '|' borders of a section banner

// Write "<dir of this module>\" (with a trailing separator) into `out`; false if it can't be built.
bool getModuleDirectory(char *out, DWORD capacity)
{
  HMODULE self = getSelfModule();
  if (!self)
    return false;

  char modulePath[MAX_PATH];
  DWORD length = GetModuleFileNameA(self, modulePath, MAX_PATH);
  if (length == 0 || length >= MAX_PATH)
    return false;

  return siblingPath(modulePath, "", out, capacity); // empty file name -> just the directory
}
} // namespace

void Logger::initialize(const char *logDirName, const char *liveLogName)
{
  InitializeCriticalSection(&writeLock);
  lockInitialized = true;

  char moduleDir[MAX_PATH];
  if (getModuleDirectory(moduleDir, sizeof moduleDir))
  {
    // "<moduleDir>logs" — create it (ok if it already exists), then keep the live log inside it.
    char dirPath[MAX_PATH];
    if (snprintf(dirPath, sizeof dirPath, "%s%s", moduleDir, logDirName) < static_cast<int>(sizeof dirPath))
    {
      CreateDirectoryA(dirPath, nullptr);
      if (snprintf(logDirectory, sizeof logDirectory, "%s\\", dirPath) >= static_cast<int>(sizeof logDirectory))
        logDirectory[0] = '\0'; // path too long: fall back to the module dir, no crash preservation
      else if (snprintf(liveLogPath, sizeof liveLogPath, "%s%s", logDirectory, liveLogName) >= static_cast<int>(sizeof liveLogPath))
        liveLogPath[0] = '\0';
    }
  }

  const char *target = liveLogPath[0] ? liveLogPath : liveLogName;
  fileHandle = CreateFileA(target, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL,
                           nullptr);
}

void Logger::preserveAsCrashLog(const char *crashLogStem, const char *crashLogExt)
{
  // Needs both the live path and its directory; without them there is nothing to copy or copy to.
  if (!lockInitialized || !logDirectory[0] || !liveLogPath[0])
    return;

  SYSTEMTIME now;
  GetLocalTime(&now);

  // "<logDir>pfixlog-YYMMDDhhmm.txt"
  char crashPath[MAX_PATH];
  int written = snprintf(crashPath, sizeof crashPath, "%s%s%02u%02u%02u%02u%02u%s", logDirectory, crashLogStem,
                         static_cast<unsigned>(now.wYear % 100), static_cast<unsigned>(now.wMonth), static_cast<unsigned>(now.wDay),
                         static_cast<unsigned>(now.wHour), static_cast<unsigned>(now.wMinute), crashLogExt);
  if (written <= 0 || written >= static_cast<int>(sizeof crashPath))
    return;

  EnterCriticalSection(&writeLock);
  if (fileHandle != INVALID_HANDLE_VALUE)
    FlushFileBuffers(fileHandle);           // ensure the on-disk live log holds the full crash report first
  CopyFileA(liveLogPath, crashPath, FALSE); // overwrite if a same-minute crash already saved one
  LeaveCriticalSection(&writeLock);
}

long long Logger::seekToEnd()
{
  LARGE_INTEGER zero{};
  LARGE_INTEGER end{};
  if (!SetFilePointerEx(fileHandle, zero, &end, FILE_END))
    return -1;
  return end.QuadPart;
}

int Logger::formatTimestamp(char *out)
{
  SYSTEMTIME now;
  GetLocalTime(&now);
  return snprintf(out, sizeof "HH:MM ", "%02u:%02u ", static_cast<unsigned>(now.wHour), static_cast<unsigned>(now.wMinute));
}

void Logger::emitAtEnd(const char *buffer, int length)
{
  if (!lockInitialized)
    return;
  EnterCriticalSection(&writeLock);
  if (fileHandle != INVALID_HANDLE_VALUE && seekToEnd() >= 0)
  {
    DWORD bytesWritten;
    WriteFile(fileHandle, buffer, static_cast<DWORD>(length), &bytesWritten, nullptr);
    FlushFileBuffers(fileHandle); // durable per line, to capture state pre-crash
  }
  LeaveCriticalSection(&writeLock);
}

void Logger::writeRawLine(const char *text)
{
  char lineBuffer[512];
  int length = 0;
  while (text[length] && length < static_cast<int>(sizeof lineBuffer) - 2)
  {
    lineBuffer[length] = text[length];
    ++length;
  }
  lineBuffer[length++] = '\n';
  emitAtEnd(lineBuffer, length);
}

void Logger::rule()
{
  char line[bannerInner + 3];
  line[0] = '+';
  for (int i = 1; i <= bannerInner; ++i)
    line[i] = '-';
  line[bannerInner + 1] = '+';
  line[bannerInner + 2] = '\0';
  writeRawLine(line);
}

void Logger::section(const char *title)
{
  writeRawLine("");
  rule();

  char row[bannerInner + 3];
  row[0] = '|';
  int at = 1;
  row[at++] = ' ';
  row[at++] = ' ';
  for (const char *s = title; *s && at < bannerInner + 1; ++s)
    row[at++] = *s;
  while (at < bannerInner + 1)
    row[at++] = ' ';
  row[bannerInner + 1] = '|';
  row[bannerInner + 2] = '\0';
  writeRawLine(row);

  rule();
}

void Logger::writeLine(const char *format, ...)
{
  va_list args;
  va_start(args, format);
  writeLineV(format, args);
  va_end(args);
}

void Logger::writeLineV(const char *format, va_list args)
{
  char lineBuffer[512];

  int prefix = formatTimestamp(lineBuffer);
  int length = vsnprintf(lineBuffer + prefix, sizeof lineBuffer - prefix - 1, format, args);

  if (length < 0)
    return;
  length += prefix;
  if (length > static_cast<int>(sizeof lineBuffer) - 2)
    length = static_cast<int>(sizeof lineBuffer) - 2; // truncate but stay framed
  lineBuffer[length++] = '\n';

  emitAtEnd(lineBuffer, length);
}

void Logger::updateLine(const char *format, ...)
{
  char lineBuffer[512];

  int prefix = formatTimestamp(lineBuffer);
  va_list args;
  va_start(args, format);
  int content = vsnprintf(lineBuffer + prefix, sizeof lineBuffer - prefix, format, args);
  va_end(args);

  if (content < 0)
    return;
  content += prefix;
  const int maxContent = static_cast<int>(sizeof lineBuffer) - 2; // leave room for '\n'
  if (content > maxContent)
    content = maxContent;

  if (!lockInitialized)
    return;
  EnterCriticalSection(&writeLock);
  if (fileHandle != INVALID_HANDLE_VALUE)
  {
    const long long end = seekToEnd();
    // Overwrite in place only while our line is still the tail; otherwise re-anchor at the end.
    const bool stillTail = end >= 0 && statusLineOffset >= 0 && statusLineOffset + static_cast<long long>(statusLineBytes) == end;

    // Grow-only width so a shorter update fully covers the previous line's characters.
    int width = content;
    if (stillTail && static_cast<int>(statusLineBytes) - 1 > width)
      width = static_cast<int>(statusLineBytes) - 1;
    for (int i = content; i < width; ++i)
      lineBuffer[i] = ' ';
    lineBuffer[width] = '\n';
    const DWORD total = static_cast<DWORD>(width + 1);

    LARGE_INTEGER writeAt{};
    writeAt.QuadPart = stillTail ? statusLineOffset : end;
    if (SetFilePointerEx(fileHandle, writeAt, nullptr, FILE_BEGIN))
    {
      DWORD bytesWritten;
      WriteFile(fileHandle, lineBuffer, total, &bytesWritten, nullptr);
      FlushFileBuffers(fileHandle);
      statusLineOffset = writeAt.QuadPart;
      statusLineBytes = total;
    }
  }
  LeaveCriticalSection(&writeLock);
}

} // namespace pfix
