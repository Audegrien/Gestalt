/*
  Win32CodeWriter.hpp

  Include file for Win32CodeWriter.cpp
  The production CodeWriter: protection-flipping, cache-flushing writes into the
  loaded image (VirtualProtect + memcpy + FlushInstructionCache).
*/

#ifndef PFIX_WIN32_CODE_WRITER_HPP
#define PFIX_WIN32_CODE_WRITER_HPP

#include "CodeWriter.hpp"

namespace pfix
{

class Win32CodeWriter : public CodeWriter
{
public:
  bool writeCode(void *destination, const void *source, std::size_t length) override;
  bool makeExecutable(void *address, std::size_t length) override;
};

} // namespace pfix

#endif // PFIX_WIN32_CODE_WRITER_HPP
