/*
  RelocatedDataArray.hpp

  Include file for RelocatedDataArray.win32.cpp
  Owns the external data[4096] the gateway is redirected onto, plus the trampoline
  arena. Reserves the near-module region (VirtualAlloc within +/-2GB, so disp32/rel32
  reach it) and fills it.

  Single reservation:
      [ preamble 0x1000 ][ relocated data (newDataByteSize) ][ trampoline arena 0x1000 ]
                         ^ dataBase (page-aligned)           ^ getTrampolineArena()
*/

#ifndef PFIX_RELOCATED_DATA_ARRAY_HPP
#define PFIX_RELOCATED_DATA_ARRAY_HPP

#include <cstdint>

#include "pfix_config.hpp"
#include "pfix_util.hpp"

namespace pfix
{

class Logger;
class ModuleImage;

class RelocatedDataArray
{
public:
  RelocatedDataArray() = default;
  RelocatedDataArray(const RelocatedDataArray &) = delete;
  RelocatedDataArray &operator=(const RelocatedDataArray &) = delete;

  // Reserve the near-module region, zero the data window, copy any live old entries across.
  bool allocate(const ModuleImage &image, Logger &logger);

  // Test seam: point the array at caller-owned buffers instead of a VirtualAlloc'd region.
  void initializeForTest(std::uint8_t *dataBaseBuffer, std::uint8_t *trampolineArenaBuffer)
  {
    dataBase = dataBaseBuffer;
    trampolineArena = trampolineArenaBuffer;
  }

  std::uint8_t *getTrampolineArena() const { return trampolineArena; }

  // The base a trampoline stub substitutes for the gateway `this`: dataBase shifted by the anchor.
  std::uint8_t *anchorFor(std::int64_t baseAnchorOffset) const { return dataBase + baseAnchorOffset; }

  // Map an original data[]-target VMA onto the relocated buffer.
  std::uint8_t *relocatedAddressFor(std::uint64_t originalTargetVma) const
  {
    return dataBase + relocatedDataOffset(originalTargetVma, config::gatewayDataBaseVma);
  }

private:
  std::uint8_t *dataBase = nullptr;
  std::uint8_t *trampolineArena = nullptr;
};

} // namespace pfix

#endif // PFIX_RELOCATED_DATA_ARRAY_HPP
