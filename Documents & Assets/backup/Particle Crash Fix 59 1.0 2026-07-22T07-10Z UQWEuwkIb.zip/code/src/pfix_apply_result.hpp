/*
  pfix_apply_result.hpp

  Header-only (no implementation file)
  The single source of truth for the patch run's outcome enum and the C-ABI entry
  point, shared by the engine (ParticleFixPatcher) and the version.dll proxy so the
  two can never drift. Windows-free, so the proxy stays decoupled from the engine.
*/

#ifndef PFIX_APPLY_RESULT_HPP
#define PFIX_APPLY_RESULT_HPP

namespace pfix
{

// Outcome of the patch run.
enum ApplyResult
{
  ApplyOk = 0,                  // patch set fully applied
  ApplyAbortedSafe = 1,         // aborted before any game-code write; unpatched but runnable
  ApplyAbortedInconsistent = 2, // aborted mid-write; game code is half-patched, do NOT run
};

} // namespace pfix

// C ABI entry point, called synchronously from the proxy during process attach.
extern "C" int pfix_apply(void);

#endif // PFIX_APPLY_RESULT_HPP
