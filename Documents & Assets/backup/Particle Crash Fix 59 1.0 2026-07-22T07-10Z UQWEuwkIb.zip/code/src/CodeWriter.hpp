/*
  CodeWriter.hpp

  Interface header (implemented by Win32CodeWriter)
  Host-clean interface for the patch engine's two memory ops: a code write and a
  W^X finalize.
*/

#ifndef PFIX_CODE_WRITER_HPP
#define PFIX_CODE_WRITER_HPP

#include <cstddef>

namespace pfix
{

class CodeWriter
{
public:
  // Copy into (executable) image memory, flipping page protection as needed and flushing the cache.
  virtual bool writeCode(void *destination, const void *source, std::size_t length) = 0;

  // Make a region execute+read (dropping write) once code is assembled there; flushes the cache.
  virtual bool makeExecutable(void *address, std::size_t length) = 0;

protected:
  ~CodeWriter() = default;
};

} // namespace pfix

#endif // PFIX_CODE_WRITER_HPP
