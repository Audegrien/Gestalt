/*
  VerificationGuard.cpp

  Implementation file for VerificationGuard.hpp
  The "did we miss an accessor?" safety net: guard-pages the dead old array so a
  fault handler logs and coherently services any accessor we failed to redirect.
*/

#include "pfix_features.hpp"

#if PFIX_ENABLE_VERIFICATION_GUARD

#include "VerificationGuard.hpp"

#include "Logger.hpp"
#include "pfix_config.hpp"

namespace pfix
{

VerificationGuard *VerificationGuard::activeInstance = nullptr;

void VerificationGuard::initialize(Logger &log)
{
  logger = &log;
  InitializeCriticalSection(&serviceLock);
  activeInstance = this;
  AddVectoredExceptionHandler(1, &VerificationGuard::vectoredHandler);
}

// Guard the OLD data[] interior at PAGE granularity; page-rounding leaves the partial end
// pages unguarded, so coverage is proven by a stress run past slot 121 with no UNREDIRECTED lines.
void VerificationGuard::arm(std::uint8_t *oldLow, std::uint8_t *oldHigh, std::intptr_t slide)
{
  if (InterlockedCompareExchange(&armed, 1, 0) != 0)
    return;

  oldDataLow = oldLow;
  oldDataHigh = oldHigh;
  imageSlide = slide;

  const std::uintptr_t low = (reinterpret_cast<std::uintptr_t>(oldLow) + 0xFFF) & ~0xFFFULL;
  const std::uintptr_t high = reinterpret_cast<std::uintptr_t>(oldHigh) & ~0xFFFULL;
  if (high <= low)
  {
    logger->writeLine("[pfix] guard: data[] too small to guard");
    return;
  }
  guardLow = reinterpret_cast<std::uint8_t *>(low);
  guardHigh = reinterpret_cast<std::uint8_t *>(high);

  DWORD previousProtection;
  if (VirtualProtect(guardLow, high - low, PAGE_NOACCESS, &previousProtection))
  {
    logger->writeLine("[pfix] verification guard armed: [%p,%p) over old data[] interior "
                      "(%llu KB)",
                      guardLow, guardHigh, static_cast<unsigned long long>((high - low) / 1024));
  }
  else
  {
    logger->writeLine("[pfix] WARN: VirtualProtect(guard) err=%lu - running without net", GetLastError());
  }
}

bool VerificationGuard::noteInstructionPointer(std::uintptr_t instructionPointer)
{
  for (int i = 0; i < seenInstructionPointerCount; i++)
    if (seenInstructionPointers[i] == instructionPointer)
      return false;
  if (seenInstructionPointerCount < maxTrackedInstructionPointers)
    seenInstructionPointers[seenInstructionPointerCount++] = instructionPointer;
  return true;
}

LONG CALLBACK VerificationGuard::vectoredHandler(EXCEPTION_POINTERS *exceptionInfo)
{
  VerificationGuard *self = activeInstance;
  if (!self)
    return EXCEPTION_CONTINUE_SEARCH;
  return self->handleException(exceptionInfo);
}

LONG VerificationGuard::handleException(EXCEPTION_POINTERS *exceptionInfo)
{
  EXCEPTION_RECORD *record = exceptionInfo->ExceptionRecord;
  CONTEXT *context = exceptionInfo->ContextRecord;

  // Only the thread that armed the step (and owns serviceLock) may complete it.
  if (record->ExceptionCode == EXCEPTION_SINGLE_STEP && pending.inProgress && pending.threadId == GetCurrentThreadId())
  {
    DWORD previousProtection;
    VirtualProtect(pending.pageWindow, pending.length, PAGE_NOACCESS, &previousProtection);
    pending.inProgress = false;
    LeaveCriticalSection(&serviceLock);
    return EXCEPTION_CONTINUE_EXECUTION;
  }

  if (record->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && guardLow)
  {
    std::uint8_t *faultAddress = reinterpret_cast<std::uint8_t *>(record->ExceptionInformation[1]);
    if (faultAddress >= guardLow && faultAddress < guardHigh)
    {
      EnterCriticalSection(&serviceLock);

      const std::uintptr_t instructionPointer = static_cast<std::uintptr_t>(context->Rip);
      if (noteInstructionPointer(instructionPointer))
      {
        const std::uint32_t slot = static_cast<std::uint32_t>((faultAddress - oldDataLow) / config::entrySize);
        logger->writeLine("[pfix] !! UNREDIRECTED accessor: ip=%llx (static ~%llx) slot=%u - "
                          "add to the patch set",
                          static_cast<unsigned long long>(instructionPointer),
                          static_cast<unsigned long long>(instructionPointer - imageSlide), slot);
      }

      // Open a window over the faulting page(s), single-step, and re-protect on the follow-up step.
      std::uint8_t *page = reinterpret_cast<std::uint8_t *>(reinterpret_cast<std::uintptr_t>(faultAddress) & ~0xFFFULL);
      SIZE_T length = 0x2000;
      if (page + length > guardHigh)
        length = static_cast<SIZE_T>(guardHigh - page);

      DWORD previousProtection;
      VirtualProtect(page, length, PAGE_READWRITE, &previousProtection);
      pending.inProgress = true;
      pending.threadId = GetCurrentThreadId();
      pending.pageWindow = page;
      pending.length = length;
      context->EFlags |= 0x100; // single-step
      return EXCEPTION_CONTINUE_EXECUTION;
    }
  }

  return EXCEPTION_CONTINUE_SEARCH;
}

} // namespace pfix

#endif // PFIX_ENABLE_VERIFICATION_GUARD
