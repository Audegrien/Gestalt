/*
  ParticleFixPatcher.hpp

  Include file for ParticleFixPatcher.cpp
  Top-level orchestrator: owns the collaborators and runs the whole patch set
  synchronously from DllMain, where every operation is loader-lock-safe.
*/

#ifndef PFIX_PARTICLE_FIX_PATCHER_HPP
#define PFIX_PARTICLE_FIX_PATCHER_HPP

#include "CapMonitor.hpp"
#include "CrashLogger.hpp"
#include "Logger.hpp"
#include "ModuleImage.hpp"
#include "RelocatedDataArray.hpp"
#include "pfix_apply_result.hpp"
#include "pfix_features.hpp"

// Optional layer — compiled out for a performance build.
#if PFIX_ENABLE_VERIFICATION_GUARD
#include "VerificationGuard.hpp"
#endif

namespace pfix
{

class ParticleFixPatcher
{
public:
  ParticleFixPatcher() = default;
  ParticleFixPatcher(const ParticleFixPatcher &) = delete;
  ParticleFixPatcher &operator=(const ParticleFixPatcher &) = delete;

  // Run the full patch set synchronously; returns an ApplyResult (as int for the C ABI).
  int apply();

private:
  Logger logger;
  ModuleImage image;
  RelocatedDataArray relocatedArray;
  CrashLogger crashLogger;
  CapMonitor capMonitor;

  // Optional layer — compiled out for a performance build.
#if PFIX_ENABLE_VERIFICATION_GUARD
  VerificationGuard guard;
#endif
};

} // namespace pfix

#endif // PFIX_PARTICLE_FIX_PATCHER_HPP
