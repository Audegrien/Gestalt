/*
  pfix_util.cpp

  Implementation file for pfix_util.hpp
  Portable, Windows-free pure helpers — the address arithmetic and string logic,
  unit-tested (depends only on <cstring>/<cstddef>).
*/

#include "pfix_util.hpp"

#include <cstring>

namespace pfix
{

bool siblingPath(const char *modulePath, const char *fileName, char *out, std::size_t capacity)
{
  if (!modulePath || !fileName || !out || capacity == 0)
    return false;

  // Walk back to just past the last path separator (0 if there is no separator).
  std::size_t prefixLen = std::strlen(modulePath);
  while (prefixLen > 0 && modulePath[prefixLen - 1] != '\\' && modulePath[prefixLen - 1] != '/')
    --prefixLen;

  const std::size_t fileLen = std::strlen(fileName);
  if (prefixLen + fileLen + 1 > capacity) // +1 for the terminating NUL
    return false;

  std::memcpy(out, modulePath, prefixLen);
  std::memcpy(out + prefixLen, fileName, fileLen + 1); // copy the NUL too
  return true;
}

} // namespace pfix
