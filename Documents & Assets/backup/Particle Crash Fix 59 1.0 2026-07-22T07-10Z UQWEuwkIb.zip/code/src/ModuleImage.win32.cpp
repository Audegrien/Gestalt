/*
  ModuleImage.win32.cpp

  Implementation file for ModuleImage.hpp
  The loaded target binary as an object: the ASLR slide plus resolve/read/verify
  helpers. The host-clean read/verify logic lives in ModuleImage.cpp; locating the
  module and computing the slide (the one Win32-dependent method) in
  ModuleImage.win32.cpp.
*/

#include "ModuleImage.hpp"

#include <windows.h>

namespace pfix
{

bool ModuleImage::initialize(const char *name, std::uint64_t preferredBase, LineLogger &log)
{
  logger = &log;
  moduleBase = reinterpret_cast<std::uint8_t *>(GetModuleHandleA(name));
  if (!moduleBase)
    moduleBase = reinterpret_cast<std::uint8_t *>(GetModuleHandleA(nullptr));
  if (!moduleBase)
    return false;
  imageSlide = reinterpret_cast<std::intptr_t>(moduleBase) - static_cast<std::intptr_t>(preferredBase);
  return true;
}

} // namespace pfix
