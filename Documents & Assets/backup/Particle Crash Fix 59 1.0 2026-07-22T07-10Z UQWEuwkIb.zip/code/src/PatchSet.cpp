/*
  PatchSet.cpp

  Implementation file for PatchSet.hpp
  Verifies and applies the three kinds of edit (LEA redirects, immediate bumps,
  trampolines). Host-clean byte-assembly: memory and logging go through injected
  interfaces, so the encoding logic is unit-testable.
*/

#include "PatchSet.hpp"

#include <cstring>

#include "CodeWriter.hpp"
#include "LineLogger.hpp"
#include "ModuleImage.hpp"
#include "RelocatedDataArray.hpp"
#include "pfix_util.hpp"

namespace pfix
{

namespace
{

constexpr int relativeJumpLength = 5; // E9 + rel32

// Worst-case bytes any single 16-byte-aligned stub occupies; the per-stub headroom check.
constexpr std::ptrdiff_t maxStubStride = 32;
static_assert(3 * maxStubStride <= static_cast<std::ptrdiff_t>(config::trampolineArenaBytes),
              "trampoline arena too small for three worst-case stubs");

// Emit a `jmp rel32` at `writeAt` targeting `destination`, NOP-padding up to `paddedLength`.
void emitRelativeJump(std::uint8_t *writeAt, const std::uint8_t *jumpFrom, const std::uint8_t *destination, int paddedLength)
{
  const std::int32_t relative = static_cast<std::int32_t>(relativeDisplacement(
      reinterpret_cast<std::uintptr_t>(jumpFrom), reinterpret_cast<std::uintptr_t>(destination), relativeJumpLength));
  writeAt[0] = 0xE9;
  std::memcpy(writeAt + 1, &relative, sizeof relative);
  for (int i = relativeJumpLength; i < paddedLength; i++)
    writeAt[i] = 0x90;
}

std::size_t alignUp16(std::size_t value)
{
  return (value + 15) & ~std::size_t{ 15 };
}

} // namespace

// Verification
bool PatchSet::verifyOriginalBytes() const
{
  bool allValid = true;

  for (const config::LeaRedirect &lea : config::leaRedirects)
  {
    if (!image.expectBytes(lea.instructionVma, lea.opcodePrefix, 3))
    {
      allValid = false;
      continue;
    }
    const std::int32_t displacement = image.readLeaDisplacement(lea.instructionVma);
    const std::uint64_t resolvedTarget = lea.instructionVma + 7 + static_cast<std::int64_t>(displacement);
    if (resolvedTarget != lea.originalTargetVma)
    {
      logger.writeLine("[pfix] LEA @%llx resolves to %llx, expected %llx (%s)", static_cast<unsigned long long>(lea.instructionVma),
                       static_cast<unsigned long long>(resolvedTarget), static_cast<unsigned long long>(lea.originalTargetVma),
                       lea.description);
      allValid = false;
    }
  }

  for (const config::ImmediatePatch &imm : config::immediatePatches)
  {
    const std::uint32_t current = image.readUInt32(imm.immediateVma);
    if (current != imm.oldValue)
    {
      logger.writeLine("[pfix] IMM @%llx = %#x, expected %#x (%s)", static_cast<unsigned long long>(imm.immediateVma), current,
                       imm.oldValue, imm.description);
      allValid = false;
    }
  }

  for (std::size_t i = 0; i < config::trampolineCount; ++i)
  {
    const config::TrampolinePatch &trampoline = config::trampolineAt(i);
    if (!image.expectBytes(trampoline.siteVma, trampoline.originalBytes, trampoline.patchedLength))
      allValid = false;
  }

  return allValid;
}

// Apply
bool PatchSet::applyAll() const
{
  return applyLeaRedirects() && applyImmediatePatches() && applyTrampolines();
}

bool PatchSet::applyLeaRedirects() const
{
  for (const config::LeaRedirect &lea : config::leaRedirects)
  {
    std::uint8_t *site = image.resolve(lea.instructionVma);
    std::uint8_t *newTarget = relocated.relocatedAddressFor(lea.originalTargetVma);
    const std::int64_t relative =
        relativeDisplacement(reinterpret_cast<std::uintptr_t>(site), reinterpret_cast<std::uintptr_t>(newTarget), 7);
    if (!fitsInt32(relative))
    {
      logger.writeLine("[pfix] FATAL: LEA @%llx out of disp32 range (rel=%lld) %s",
                       static_cast<unsigned long long>(lea.instructionVma), static_cast<long long>(relative), lea.description);
      return false;
    }
    const std::int32_t displacement = static_cast<std::int32_t>(relative);
    if (!writer.writeCode(site + 3, &displacement, sizeof displacement))
      return false;
    logger.writeLine("[pfix]   lea @%llx -> relocated%+lld  (%s)", static_cast<unsigned long long>(lea.instructionVma),
                     static_cast<long long>(static_cast<std::int64_t>(lea.originalTargetVma) -
                                            static_cast<std::int64_t>(config::gatewayDataBaseVma)),
                     lea.description);
  }
  return true;
}

bool PatchSet::applyImmediatePatches() const
{
  for (const config::ImmediatePatch &imm : config::immediatePatches)
  {
    const std::uint32_t value = imm.newValue;
    if (!writer.writeCode(image.resolve(imm.immediateVma), &value, sizeof value))
      return false;
    logger.writeLine("[pfix]   imm @%llx  %#x -> %#x  (%s)", static_cast<unsigned long long>(imm.immediateVma), imm.oldValue,
                     imm.newValue, imm.description);
  }
  return true;
}

bool PatchSet::applyTrampolines() const
{
  std::uint8_t *arena = relocated.getTrampolineArena();
  const std::uint8_t *arenaEnd = arena + config::trampolineArenaBytes;
  std::uint8_t *cursor = arena;

  // Each install*Stub bounds-checks against arenaEnd before writing.
  if (!installDispatcherCase0Stub(cursor, arenaEnd))
    return false;
  if (!installDispatcherCase1Stub(cursor, arenaEnd))
    return false;
  if (!installWriterStub(cursor, arenaEnd))
    return false;

  // W^X: flip the finished trampoline page to execute-only-read.
  if (!writer.makeExecutable(arena, config::trampolineArenaBytes))
    logger.writeLine("[pfix] WARN: makeExecutable(tramp, EXEC_READ) failed");
  return true;
}

// dispatcher case0 @0x1407A86B6: rsi += anchor; r8 = [rsi]. RAX scratch is push/pop-bracketed.
bool PatchSet::installDispatcherCase0Stub(std::uint8_t *&arenaCursor, const std::uint8_t *arenaEnd) const
{
  if (arenaCursor + maxStubStride > arenaEnd)
  {
    logger.writeLine("[pfix] FATAL: trampoline arena exhausted before %s", config::dispatcherCase0.description);
    return false;
  }
  std::uint8_t *const stub = arenaCursor;
  std::uint8_t *substituteBase = relocated.anchorFor(config::dispatcherCase0.baseAnchorOffset);
  int len = 0;
  stub[len++] = 0x50; // push rax
  stub[len++] = 0x48;
  stub[len++] = 0xB8;
  std::memcpy(stub + len, &substituteBase, 8);
  len += 8; // mov rax,imm64
  stub[len++] = 0x48;
  stub[len++] = 0x01;
  stub[len++] = 0xC6; // add rsi,rax
  stub[len++] = 0x58; // pop rax
  stub[len++] = 0x4C;
  stub[len++] = 0x8B;
  stub[len++] = 0x06; // mov r8,[rsi]
  return emitStub(config::dispatcherCase0, arenaCursor, len);
}

// dispatcher case1 @0x1407A877A: edx = [anchor + rax + 0x10] (data[idx].handle); redo cmp.
bool PatchSet::installDispatcherCase1Stub(std::uint8_t *&arenaCursor, const std::uint8_t *arenaEnd) const
{
  if (arenaCursor + maxStubStride > arenaEnd)
  {
    logger.writeLine("[pfix] FATAL: trampoline arena exhausted before %s", config::dispatcherCase1.description);
    return false;
  }
  std::uint8_t *const stub = arenaCursor;
  std::uint8_t *substituteBase = relocated.anchorFor(config::dispatcherCase1.baseAnchorOffset);
  int len = 0;
  stub[len++] = 0x51; // push rcx
  stub[len++] = 0x48;
  stub[len++] = 0xB9;
  std::memcpy(stub + len, &substituteBase, 8);
  len += 8; // mov rcx,imm64
  stub[len++] = 0x8B;
  stub[len++] = 0x54;
  stub[len++] = 0x01;
  stub[len++] = 0x10; // mov edx,[rcx+rax+0x10]
  stub[len++] = 0x59; // pop rcx
  stub[len++] = 0x83;
  stub[len++] = 0xFA;
  stub[len++] = 0xFF; // cmp edx,-1
  return emitStub(config::dispatcherCase1, arenaCursor, len);
}

// writer @0x1407A8656: r9 = anchor (-0x10); mov [rcx+r9+0x24], eax. r9 is left holding the
// relocated base on purpose, so downstream reuse resolves into the relocated array too.
bool PatchSet::installWriterStub(std::uint8_t *&arenaCursor, const std::uint8_t *arenaEnd) const
{
  if (arenaCursor + maxStubStride > arenaEnd)
  {
    logger.writeLine("[pfix] FATAL: trampoline arena exhausted before %s", config::writer.description);
    return false;
  }
  std::uint8_t *const stub = arenaCursor;
  std::uint8_t *substituteBase = relocated.anchorFor(config::writer.baseAnchorOffset);
  int len = 0;
  stub[len++] = 0x49;
  stub[len++] = 0xB9;
  std::memcpy(stub + len, &substituteBase, 8);
  len += 8; // mov r9,imm64
  stub[len++] = 0x42;
  stub[len++] = 0x89;
  stub[len++] = 0x44; // mov [rcx+r9*1+0x24],eax
  stub[len++] = 0x09;
  stub[len++] = 0x24;
  return emitStub(config::writer, arenaCursor, len);
}

bool PatchSet::emitStub(const config::TrampolinePatch &patch, std::uint8_t *&arenaCursor, int bodyLength) const
{
  std::uint8_t *const stub = arenaCursor;

  // Append the resume JMP after the middle instructions.
  std::uint8_t *const resumeJumpSite = stub + bodyLength;
  emitRelativeJump(resumeJumpSite, resumeJumpSite, image.resolve(patch.resumeVma), relativeJumpLength);
  const int stubLength = bodyLength + relativeJumpLength;

  // Overwrite the original site with a JMP into the stub, NOP-padded to patchedLength.
  std::uint8_t siteJump[16];
  std::uint8_t *const siteLive = image.resolve(patch.siteVma);
  emitRelativeJump(siteJump, siteLive, stub, patch.patchedLength);
  if (!writer.writeCode(siteLive, siteJump, patch.patchedLength))
    return false;

  logger.writeLine("[pfix]   trampoline %s @%llx -> stub %p (%d bytes)", patch.description,
                   static_cast<unsigned long long>(patch.siteVma), static_cast<void *>(stub), stubLength);

  arenaCursor += alignUp16(static_cast<std::size_t>(stubLength));
  return true;
}

} // namespace pfix
