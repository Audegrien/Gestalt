/*
  VerificationGuard.hpp

  Include file for VerificationGuard.cpp
  The "did we miss an accessor?" safety net: guard-pages the dead old array so a
  fault handler logs and coherently services any accessor we failed to redirect.
*/

#ifndef PFIX_VERIFICATION_GUARD_HPP
#define PFIX_VERIFICATION_GUARD_HPP

#include <cstdint>
#include <windows.h>

namespace pfix
{

class Logger;

class VerificationGuard
{
public:
  VerificationGuard() = default;
  VerificationGuard(const VerificationGuard &) = delete;
  VerificationGuard &operator=(const VerificationGuard &) = delete;

  // Prepare the service lock and register the vectored handler; inert until arm().
  void initialize(Logger &logger);

  // Guard the old data[] interior and flip it to PAGE_NOACCESS; idempotent.
  void arm(std::uint8_t *oldLow, std::uint8_t *oldHigh, std::intptr_t slide);

private:
  // Instance fault handler; the static callback forwards here via activeInstance.
  LONG handleException(EXCEPTION_POINTERS *exceptionInfo);
  static LONG CALLBACK vectoredHandler(EXCEPTION_POINTERS *exceptionInfo);

  // Record a faulting IP once; true the first time a given IP is seen.
  bool noteInstructionPointer(std::uintptr_t instructionPointer);

  // A fault -> single-step round-trip, owned by one thread at a time under the service lock.
  struct PendingSingleStep
  {
    bool inProgress = false;
    DWORD threadId = 0;
    std::uint8_t *pageWindow = nullptr;
    SIZE_T length = 0;
  };

  static constexpr int maxTrackedInstructionPointers = 512;

  static VerificationGuard *activeInstance;

  Logger *logger = nullptr;
  volatile LONG armed = 0;
  std::uint8_t *guardLow = nullptr;
  std::uint8_t *guardHigh = nullptr;
  std::uint8_t *oldDataLow = nullptr;
  std::uint8_t *oldDataHigh = nullptr;
  std::intptr_t imageSlide = 0;
  CRITICAL_SECTION serviceLock{};
  PendingSingleStep pending{};
  std::uintptr_t seenInstructionPointers[maxTrackedInstructionPointers]{};
  int seenInstructionPointerCount = 0;
};

} // namespace pfix

#endif // PFIX_VERIFICATION_GUARD_HPP
