/*
  Win32CodeWriter.cpp

  Implementation file for Win32CodeWriter.hpp
  The production CodeWriter: protection-flipping, cache-flushing writes into the
  loaded image (VirtualProtect + memcpy + FlushInstructionCache).
*/

#include "Win32CodeWriter.hpp"

#include <cstring>
#include <windows.h>

namespace pfix
{

bool Win32CodeWriter::writeCode(void *destination, const void *source, std::size_t length)
{
  DWORD previousProtection;
  if (!VirtualProtect(destination, length, PAGE_EXECUTE_READWRITE, &previousProtection))
    return false;
  std::memcpy(destination, source, length);
  // Best-effort restore; the bytes already landed and the cache flush below is what matters.
  VirtualProtect(destination, length, previousProtection, &previousProtection);
  FlushInstructionCache(GetCurrentProcess(), destination, length);
  return true;
}

bool Win32CodeWriter::makeExecutable(void *address, std::size_t length)
{
  DWORD previousProtection;
  const bool ok = VirtualProtect(address, length, PAGE_EXECUTE_READ, &previousProtection) != 0;
  FlushInstructionCache(GetCurrentProcess(), address, length);
  return ok;
}

} // namespace pfix
