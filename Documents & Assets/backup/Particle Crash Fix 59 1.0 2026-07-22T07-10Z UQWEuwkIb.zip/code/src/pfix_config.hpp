/*
  pfix_config.hpp

  Header-only (no implementation file)
  Patch tables and constants as typed constexpr data. All addresses are STATIC VMAs
  (preferred base 0x140000000); a slide computed from the real module base is added
  at runtime.
*/

#ifndef PFIX_CONFIG_HPP
#define PFIX_CONFIG_HPP

#include <cstddef>
#include <cstdint>

namespace pfix::config
{

// Module / image
inline constexpr std::uint64_t preferredImageBase = 0x140000000ULL;
inline constexpr char moduleName[] = "xgameFinal.exe";

// Gateway object (gParticleGateway) layout
inline constexpr std::uint64_t gatewayObjectVma = 0x141850090ULL;                         // object base
inline constexpr std::uint64_t gatewayDataOffset = 0x20;                                  // data[] within object
inline constexpr std::uint64_t gatewayDataBaseVma = gatewayObjectVma + gatewayDataOffset; // data[] base (0x1418500B0)
inline constexpr std::uint32_t originalSlotCount = 512;                                   // cMaxDataSlots (original)
inline constexpr std::uint64_t entrySize = 0x20;                                          // bytes per data[] slot

// Running count of in-use slots, laid out immediately after data[512]; the value compared at the
// CAP GATE. Left at its fixed VMA by the data-only relocation; kept only as a layout anchor.
inline constexpr std::uint64_t liveCountVma = gatewayDataBaseVma + (originalSlotCount * entrySize); // 0x1418540B0

// Target cap
inline constexpr std::uint32_t newSlotCount = 4096;                        // 0x1000
inline constexpr std::uint64_t newDataByteSize = newSlotCount * entrySize; // 0x20000

// Bytes reserved after the data window for the 3 generated stubs; single-owned (reserver == protector).
inline constexpr std::size_t trampolineArenaBytes = 0x1000;

// Bytes reserved below dataBase so the smallest anchor (dataBase-0x20) stays inside the reservation.
inline constexpr std::size_t relocationPreambleBytes = 0x1000;

// Key code site (layout anchor): the cap-gate compare; its imm32 is siteCapCompare+2.
inline constexpr std::uint64_t siteCapCompare = 0x1407A7940ULL; // cmp ecx,0x200 -> 0x1000

// Log folder created next to our module; live log overwritten each run, crash log kept per run.
inline constexpr char logDirName[] = "logs";
inline constexpr char liveLogName[] = "pfixlog.txt";
inline constexpr char crashLogStem[] = "pfixlog-"; // + YYMMDDhhmm + crashLogExt
inline constexpr char crashLogExt[] = ".txt";

// Patch table 1 — absolute data[]-base LEA redirects. Each disp32 is rewritten to target
// relocatedArray + (originalTarget - gatewayDataBase).
struct LeaRedirect
{
  std::uint64_t instructionVma;    // address of the LEA instruction
  std::uint64_t originalTargetVma; // address the original disp32 resolves to
  std::uint8_t opcodePrefix[3];    // REX + opcode + modrm asserted before patching
  const char *description;
};

inline constexpr LeaRedirect leaRedirects[] = {
  { 0x140369F74ULL, 0x1418500B0ULL, { 0x48, 0x8d, 0x35 }, "serializer (rsi)" },
  { 0x1407A74EFULL, 0x1418500B0ULL, { 0x48, 0x8d, 0x0d }, "global ctor eh_vector" },
  { 0x1407A777FULL, 0x1418500B8ULL, { 0x48, 0x8d, 0x1d }, "clear-all loop (rbx)" },
  { 0x1407A78F3ULL, 0x141850090ULL, { 0x48, 0x8d, 0x2d }, "getOrCreateData rbp" },
  { 0x1407A795AULL, 0x1418500B0ULL, { 0x48, 0x8d, 0x05 }, "getOrCreateData alloc" },
  { 0x1407A830FULL, 0x1418500B8ULL, { 0x48, 0x8d, 0x1d }, "releaseAll loop (rbx)" },
  { 0x140F08748ULL, 0x1418500B0ULL, { 0x48, 0x8d, 0x0d }, "atexit dtor eh_vector" },
};

// Patch table 2 — immediates. Assert `oldValue`, then write `newValue`. The five 0x200 sites are
// the cap gate + loop/element counts; the class-dtor's 0x200 imm32 @0x1407A75D1 is deliberately absent.
struct ImmediatePatch
{
  std::uint64_t immediateVma; // address of the imm32 to rewrite
  std::uint32_t oldValue;     // value asserted before patching
  std::uint32_t newValue;     // value written
  const char *description;
};

inline constexpr ImmediatePatch immediatePatches[] = {
  { 0x1407A74EBULL, 0x200, newSlotCount, "ctor eh_vector elem count" },
  { 0x1407A7787ULL, 0x200, newSlotCount, "clear-all loop count" },
  { 0x1407A7942ULL, 0x200, newSlotCount, "CAP GATE cmp ecx,0x200" },
  { 0x1407A8317ULL, 0x200, newSlotCount, "releaseAll loop count" },
  { 0x140F08744ULL, 0x200, newSlotCount, "atexit dtor elem count" },
  { 0x140369F2CULL, 0x3E8, newSlotCount, "serializer save ceiling" },
};

// Patch table 3 — runtime-`this` inline trampolines. Each site's access is overwritten with a JMP
// into a stub (byte sequences in PatchSet.cpp) that recomputes the address against the relocated
// array. `baseAnchorOffset` is the field offset the compiler folded into the base register at that
// site (entry layout = {+0x00 name(8), +0x08 refcount, +0x10 handle, +0x14 state}):
//   dispatcher case0 0x1407A86B6: rsi=(idx+1)*0x20 -> &data[idx]       -> anchor -0x20
//   dispatcher case1 0x1407A877A: rax=(idx+1)*0x20 -> data[idx].handle -> anchor -0x20
//   writer           0x1407A8656: rcx=idx*0x20 -> data[idx].state, r9 -> anchor -0x10 (not -0x20,
//       which would corrupt the name pointer's high dword)
struct TrampolinePatch
{
  std::uint64_t siteVma;         // where the JMP is written
  std::uint64_t resumeVma;       // where the stub jumps back to
  std::int64_t baseAnchorOffset; // relocatedBase + this == subtract from relocated base
  std::uint8_t originalBytes[7]; // asserted before patching (patchedLength bytes used)
  std::uint8_t patchedLength;    // bytes overwritten at the site (JMP + NOP pad)
  const char *description;
};

inline constexpr TrampolinePatch dispatcherCase0{
  0x1407A86B6ULL, 0x1407A86BCULL, -0x20, { 0x48, 0x03, 0xf7, 0x4c, 0x8b, 0x06, 0x00 }, 6, "dispatcher.case0 (rsi base)",
};

inline constexpr TrampolinePatch dispatcherCase1{
  0x1407A877AULL, 0x1407A8781ULL, -0x20, { 0x8b, 0x54, 0x38, 0x10, 0x83, 0xfa, 0xff }, 7, "dispatcher.case1 (rdi base)",
};

inline constexpr TrampolinePatch writer{
  0x1407A8656ULL, 0x1407A865BULL, -0x10, { 0x42, 0x89, 0x44, 0x09, 0x24, 0x00, 0x00 }, 5, "writer (r9 base, anchor -0x10)",
};

// Compile-time invariants over the patch tables: the static_asserts below fire in every build,
// so a mistyped address, cap value, or oversized table is a compile error rather than a bad exe.

inline constexpr std::size_t leaCount = sizeof(leaRedirects) / sizeof(leaRedirects[0]);
inline constexpr std::size_t immediateCount = sizeof(immediatePatches) / sizeof(immediatePatches[0]);
inline constexpr std::size_t trampolineCount = 3;
inline constexpr std::size_t patchSiteCount = leaCount + immediateCount + trampolineCount;

// Byte length written at each site: a LEA is 7, an imm32 is 4, a trampoline overwrites patchedLength.
inline constexpr std::size_t leaSiteLength = 7;
inline constexpr std::size_t immediateSiteLength = 4;

constexpr const TrampolinePatch &trampolineAt(std::size_t index)
{
  if (index == 0)
    return dispatcherCase0;
  if (index == 1)
    return dispatcherCase1;
  return writer;
}

// The start VMA of the index-th patch site over [ LEAs | immediates | trampolines ].
constexpr std::uint64_t patchSiteStart(std::size_t index)
{
  if (index < leaCount)
    return leaRedirects[index].instructionVma;
  if (index < leaCount + immediateCount)
    return immediatePatches[index - leaCount].immediateVma;
  return trampolineAt(index - leaCount - immediateCount).siteVma;
}

constexpr std::uint64_t patchSiteLength(std::size_t index)
{
  if (index < leaCount)
    return leaSiteLength;
  if (index < leaCount + immediateCount)
    return immediateSiteLength;
  return trampolineAt(index - leaCount - immediateCount).patchedLength;
}

// No two patched byte ranges may overlap; adjacency is fine (immediates sit just before their LEA).
constexpr bool anyPatchSitesOverlap()
{
  for (std::size_t first = 0; first < patchSiteCount; ++first)
    for (std::size_t second = first + 1; second < patchSiteCount; ++second)
    {
      const std::uint64_t startFirst = patchSiteStart(first);
      const std::uint64_t endFirst = startFirst + patchSiteLength(first);
      const std::uint64_t startSecond = patchSiteStart(second);
      const std::uint64_t endSecond = startSecond + patchSiteLength(second);
      if (startFirst < endSecond && startSecond < endFirst)
        return true;
    }
  return false;
}

// Every LEA's redirected target must land inside the reserved window, or its disp32 points outside it.
constexpr bool allLeaTargetsInWindow()
{
  const std::int64_t low = -static_cast<std::int64_t>(relocationPreambleBytes);
  const std::int64_t high = static_cast<std::int64_t>(newDataByteSize);
  for (std::size_t i = 0; i < leaCount; ++i)
  {
    const std::int64_t offset =
        static_cast<std::int64_t>(leaRedirects[i].originalTargetVma) - static_cast<std::int64_t>(gatewayDataBaseVma);
    if (offset < low || offset >= high)
      return false;
  }
  return true;
}

// Each LEA prefix must be a REX.W `lea` (0x48 0x8d ...); the modrm varies per destination register.
constexpr bool allLeaOpcodesWellFormed()
{
  for (std::size_t i = 0; i < leaCount; ++i)
    if (leaRedirects[i].opcodePrefix[0] != 0x48 || leaRedirects[i].opcodePrefix[1] != 0x8d)
      return false;
  return true;
}

// Every immediate patch raises its site to the new cap.
constexpr bool allImmediatesRaiseToNewCap()
{
  for (std::size_t i = 0; i < immediateCount; ++i)
    if (immediatePatches[i].newValue != newSlotCount)
      return false;
  return true;
}

constexpr std::size_t immediatesWithOldValue(std::uint32_t value)
{
  std::size_t n = 0;
  for (std::size_t i = 0; i < immediateCount; ++i)
    if (immediatePatches[i].oldValue == value)
      ++n;
  return n;
}

// Each trampoline needs room for a JMP rel32 within its asserted span, and an anchor in the preamble window.
constexpr bool allTrampolinesWellFormed()
{
  for (std::size_t k = 0; k < trampolineCount; ++k)
  {
    const TrampolinePatch &t = trampolineAt(k);
    if (t.patchedLength < 5 || t.patchedLength > sizeof(t.originalBytes))
      return false;
    if (t.baseAnchorOffset > 0 || t.baseAnchorOffset < -static_cast<std::int64_t>(relocationPreambleBytes))
      return false;
  }
  return true;
}

static_assert(newSlotCount > originalSlotCount, "the fix must RAISE the cap");
static_assert(newDataByteSize == static_cast<std::uint64_t>(newSlotCount) * entrySize, "newDataByteSize desync");
static_assert(gatewayDataBaseVma == gatewayObjectVma + gatewayDataOffset, "data[] base desync");
static_assert(!anyPatchSitesOverlap(), "two patch sites overlap");
static_assert(allLeaTargetsInWindow(), "a LEA target falls outside the relocated window");
static_assert(allLeaOpcodesWellFormed(), "a LEA opcode prefix is not REX.W lea");
static_assert(allImmediatesRaiseToNewCap(), "an immediate patch does not raise to newSlotCount");
static_assert(immediatesWithOldValue(originalSlotCount) == 5, "expected exactly 5 cap (512) immediates");
static_assert(immediatesWithOldValue(0x3E8) == 1, "expected exactly 1 save-ceiling (1000) immediate");
static_assert(immediatesWithOldValue(originalSlotCount) + immediatesWithOldValue(0x3E8) == immediateCount,
              "an immediate has an unexpected old value");
static_assert(allTrampolinesWellFormed(), "a trampoline is malformed");

} // namespace pfix::config

#endif // PFIX_CONFIG_HPP
