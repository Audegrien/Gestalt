/*
  Logger.hpp

  Include file for Logger.cpp
  Allocation-free, critical-section-guarded line logger, safe inside a fault
  handler: formats to a stack buffer and WriteFile()s (no heap allocation).
*/

#ifndef PFIX_LOGGER_HPP
#define PFIX_LOGGER_HPP

#include <cstdarg>
#include <windows.h>

#include "LineLogger.hpp"

namespace pfix
{

class Logger
{
public:
  Logger() = default;
  Logger(const Logger &) = delete;
  Logger &operator=(const Logger &) = delete;

  // Create the log folder next to our module, open the live log, init the lock; call once.
  void initialize(const char *logDirName, const char *liveLogName);

  // Copy the live log to a timestamped crash log so this run survives the next launch's overwrite.
  void preserveAsCrashLog(const char *crashLogStem, const char *crashLogExt);

  // printf-style, newline-terminated, serialized, flushed per line.
  void writeLine(const char *format, ...);

  // va_list form doing the actual work, so adapters can forward a variadic pack.
  void writeLineV(const char *format, va_list args);

  // Like writeLine, but overwrites the previously-updated line in place while it stays the tail.
  void updateLine(const char *format, ...);

  // Framed banner introducing a log section (blank line + boxed title).
  void section(const char *title);

  // A single horizontal rule matching the banner width; closes a section.
  void rule();

private:
  // Seek the write pointer to end-of-file (caller holds writeLock); returns the offset, or -1.
  long long seekToEnd();

  // Write the local "HH:MM " prefix into out; returns its length.
  int formatTimestamp(char *out);

  // Append length bytes at end-of-file, flushed, serialized under writeLock.
  void emitAtEnd(const char *buffer, int length);

  // Append text + '\n' at end-of-file with no timestamp (for banners and blank lines).
  void writeRawLine(const char *text);

  HANDLE fileHandle = INVALID_HANDLE_VALUE;
  CRITICAL_SECTION writeLock{};
  bool lockInitialized = false;

  // Log directory (with trailing separator) and the live log's full path, for crash preservation.
  char logDirectory[MAX_PATH] = {};
  char liveLogPath[MAX_PATH] = {};

  // Tail-overwrite state for updateLine(); offset < 0 means no status line written yet.
  long long statusLineOffset = -1;
  DWORD statusLineBytes = 0;
};

// Stack-built runtime adapter presenting the concrete Logger as a LineLogger for the patch engine.
class LoggerLineSink : public LineLogger
{
public:
  explicit LoggerLineSink(Logger &target) : logger(target) { }

  void writeLine(const char *format, ...) override
  {
    va_list args;
    va_start(args, format);
    logger.writeLineV(format, args);
    va_end(args);
  }

private:
  Logger &logger;
};

} // namespace pfix

#endif // PFIX_LOGGER_HPP
