/*
  version_proxy.cpp

  Standalone translation unit (no header)
  The version.dll proxy: forwards the real version.dll exports and applies the
  particle-cap patch in DllMain.
*/

#include <windows.h>

#include "pfix_apply_result.hpp"

extern "C"
{

  // Fallback for any export that fails to resolve: return 0 rather than jump through NULL.
  long pfix_ver_default_stub(void)
  {
    return 0;
  }

// One 8-byte slot per forwarded export, defaulted to the stub so the thunks are always safe.
#define SLOT(name) void *real_##name = reinterpret_cast<void *>(&pfix_ver_default_stub)
  SLOT(GetFileVersionInfoA);
  SLOT(GetFileVersionInfoByHandle);
  SLOT(GetFileVersionInfoExA);
  SLOT(GetFileVersionInfoExW);
  SLOT(GetFileVersionInfoSizeA);
  SLOT(GetFileVersionInfoSizeExA);
  SLOT(GetFileVersionInfoSizeExW);
  SLOT(GetFileVersionInfoSizeW);
  SLOT(GetFileVersionInfoW);
  SLOT(VerFindFileA);
  SLOT(VerFindFileW);
  SLOT(VerInstallFileA);
  SLOT(VerInstallFileW);
  SLOT(VerQueryValueA);
  SLOT(VerQueryValueW);
#undef SLOT

} // extern "C"

namespace
{

#define ENTRY(name) { #name, &real_##name }
const struct
{
  const char *name;
  void **target;
} forwardedExports[] = {
  ENTRY(GetFileVersionInfoA),
  ENTRY(GetFileVersionInfoByHandle),
  ENTRY(GetFileVersionInfoExA),
  ENTRY(GetFileVersionInfoExW),
  ENTRY(GetFileVersionInfoSizeA),
  ENTRY(GetFileVersionInfoSizeExA),
  ENTRY(GetFileVersionInfoSizeExW),
  ENTRY(GetFileVersionInfoSizeW),
  ENTRY(GetFileVersionInfoW),
  ENTRY(VerFindFileA),
  ENTRY(VerFindFileW),
  ENTRY(VerInstallFileA),
  ENTRY(VerInstallFileW),
  ENTRY(VerQueryValueA),
  ENTRY(VerQueryValueW),
};
#undef ENTRY

// Load the genuine System32\version.dll (by absolute path) and point each slot at the real function.
void resolveForwardedExports()
{
  char path[MAX_PATH];
  UINT length = GetSystemDirectoryA(path, MAX_PATH);
  if (length == 0 || length > MAX_PATH - static_cast<UINT>(sizeof("\\version.dll")))
    return; // can't build the path; keep stubs
  lstrcatA(path, "\\version.dll");

  HMODULE realModule = LoadLibraryExA(path, nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
  if (!realModule)
    return; // keep stubs

  for (const auto &forward : forwardedExports)
  {
    FARPROC procedure = GetProcAddress(realModule, forward.name);
    if (procedure)
      *forward.target = reinterpret_cast<void *>(procedure);
  }
}

} // namespace

extern "C" BOOL WINAPI DllMain(HINSTANCE moduleHandle, DWORD reason, LPVOID reserved)
{
  (void)reserved;
  if (reason == DLL_PROCESS_ATTACH)
  {
    DisableThreadLibraryCalls(moduleHandle);
    resolveForwardedExports();       // wire real version.dll exports first
    const int result = pfix_apply(); // then apply the cap patch (early)

    // A half-patched exe is worse than the original clean assert; fail process init so it never runs.
    if (result == pfix::ApplyAbortedInconsistent)
      return FALSE;
  }
  return TRUE;
}
