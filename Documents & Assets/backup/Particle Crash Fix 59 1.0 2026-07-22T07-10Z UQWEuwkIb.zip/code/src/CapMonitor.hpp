/*
  CapMonitor.hpp

  Include file for CapMonitor.cpp
  A daemon thread polling the gateway's live-slot count; logs the current count once a minute.
*/

#ifndef PFIX_CAP_MONITOR_HPP
#define PFIX_CAP_MONITOR_HPP

#include <cstdint>
#include <windows.h>

namespace pfix
{

class Logger;
class ModuleImage;

class CapMonitor
{
public:
  CapMonitor() = default;
  CapMonitor(const CapMonitor &) = delete;
  CapMonitor &operator=(const CapMonitor &) = delete;

  // Resolve the live-count field and launch the poll thread; safe from DllMain.
  void start(Logger &logger, const ModuleImage &image);

private:
  static DWORD WINAPI threadMain(LPVOID parameter);
  void pollLoop();

  static constexpr DWORD pollIntervalMs = 60 * 1000; // one live-count line per minute

  Logger *logger = nullptr;
  const volatile std::uint32_t *liveCount = nullptr;
};

} // namespace pfix

#endif // PFIX_CAP_MONITOR_HPP
