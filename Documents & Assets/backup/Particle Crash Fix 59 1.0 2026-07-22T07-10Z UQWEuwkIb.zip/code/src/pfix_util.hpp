/*
  pfix_util.hpp

  Include file for pfix_util.cpp
  Portable, Windows-free pure helpers — the address arithmetic and string logic,
  unit-tested (depends only on <cstring>/<cstddef>).
*/

#ifndef PFIX_UTIL_HPP
#define PFIX_UTIL_HPP

#include <cstddef>
#include <cstdint>

namespace pfix
{

// Signed byte offset of an original data[]-target VMA from the gateway data[] base.
constexpr std::int64_t relocatedDataOffset(std::uint64_t originalTargetVma, std::uint64_t gatewayDataBaseVma)
{
  return static_cast<std::int64_t>(originalTargetVma) - static_cast<std::int64_t>(gatewayDataBaseVma);
}

// Full (un-truncated) displacement a RIP-relative reference needs: target - (fromInstr + operandLength).
constexpr std::int64_t relativeDisplacement(std::uint64_t fromInstr, std::uint64_t target, int operandLength)
{
  return static_cast<std::int64_t>(target) - (static_cast<std::int64_t>(fromInstr) + operandLength);
}

// True if `value` fits in a signed 32-bit field (the reach of a disp32/rel32).
constexpr bool fitsInt32(std::int64_t value)
{
  return value >= INT32_MIN && value <= INT32_MAX;
}

// Build "<directory of modulePath><fileName>" into out[capacity]; false if it won't fit.
bool siblingPath(const char *modulePath, const char *fileName, char *out, std::size_t capacity);

} // namespace pfix

#endif // PFIX_UTIL_HPP
