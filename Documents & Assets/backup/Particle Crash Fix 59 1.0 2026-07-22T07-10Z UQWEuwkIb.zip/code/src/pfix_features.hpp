/*
  pfix_features.hpp

  Header-only (no implementation file)
  Compile-time toggle for the debug build verification guard; default OFF
*/

#ifndef PFIX_FEATURES_HPP
#define PFIX_FEATURES_HPP

#ifndef PFIX_ENABLE_VERIFICATION_GUARD
#define PFIX_ENABLE_VERIFICATION_GUARD 0
#endif

#endif // PFIX_FEATURES_HPP
