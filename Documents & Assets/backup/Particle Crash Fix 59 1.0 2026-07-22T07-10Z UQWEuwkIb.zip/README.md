# Particle Crash Fix for Halo Wars: Definitive Edition

Fixes the particle-system crash that ends custom leader matches with a hard lockup.
The game caps the number of distinct particle effect definitions it can load at 512
(`cMaxDataSlots`); when a busy scene needs a 513th, the engine deliberately aborts with:

> `BParticleGateway::getOrCreateData: Increase cMaxDataSlots!`

This mod raises that cap to 4096 at runtime, so every effect loads and renders with
no crash and no invisible particles.

**Important** - Please read the "Compatibility & limits" section in its entirety.

---

## How the patch is loaded

This mod ships as a single `version.dll`. Windows already loads a `version.dll` for the
game, and it looks in the game folder first — so a copy placed next to `xgameFinal.exe` is
picked up automatically when you launch the game normally from Steam. It forwards every
real `version.dll` call straight through to Windows, and on startup applies the cap fix in
memory.

---

## Install

Copy only `version.dll` into the game folder.

e.g. the folder that contains `xgameFinal.exe` `...\Steam\steamapps\common\HaloWarsDE\`

> If a `version.dll` is already there, it belongs to another mod. Only one `version.dll` can exist.

## Uninstall

Delete only `version.dll` from the game folder.

---

## Crash logging and verifying the mod is working

This mod includes a crash logger that will provide helpful information for mod developers.
If you ever experience a crash, a timestamped log file will be created for your reference.
All logging is stored via a `logs` directory in your game folder. Within you will find a file
`pfixlog.txt` that updates you on the mod's success status, as well as provide you
with live updates tracking how many particles are currently defined.

---

## Compatibility & limits

- Offline Single-player Campaign and Skirmish: Working - This is the intended use case.
- Online Multiplayer and Skirmish: Untested - The cap change does not affect the synced simulation
  (particles are client-side render assets), but running a modded client against unmodded players is
  untested — treat it as use **at-your-own-risk** (see below).
- Anti-cheat / bans: Halo Wars DE ships no client-side anti-tamper **that I could find**, and this mod changes
  no file on disk. There is no known ban vector for offline play. If you'd like to guarantee
  your safety, click "Steam -> Go Offline". Online usage is **at-your-own-risk**.
  For the sake of transparency; this mod would be extremely easy to detect from the developers'
  perspective, and it's unknown if they have any safeguards enabled server-side.
  Other mods do similar things, with no reported bans, but I cannot exclude the risk associated.
  Unfortunately, engine mods such as these are only possible with the tactics used here.

---

## "My antivirus flagged version.dll"

This is a false positive with a known cause: a `version.dll` placed next to a game is the
same technique used by both legitimate mods (ENB, ReShade, script extenders) and, rarely,
by malware — so heuristic scanners flag the shape, not the behaviour. To reassure yourself:

- Check the **`SHA256SUMS.txt`** in this archive against the file you downloaded:
  - Windows PowerShell: `Get-FileHash version.dll -Algorithm SHA256`
  - the value must match the `version.dll` line in `SHA256SUMS.txt`.
- Upload `version.dll` to **[VirusTotal](https://www.virustotal.com/)** and compare.
- The **full source is bundled in this download** in the `code/` folder — it builds
  reproducibly (`./.docker/build.sh` from inside that folder), so you can inspect exactly
  what the DLL does and rebuild it yourself.

`version.dll` is **unsigned** — this is a free mod with no code-signing certificate, so Windows
shows no publisher and SmartScreen may warn on first launch. That is expected; verify the download
with the `SHA256SUMS.txt` and VirusTotal checks above rather than by a digital signature.

---

## Credits & license

This mod is an unofficial fan mod and is not affiliated with or endorsed by the game's
publisher or developer. See `LICENSE` for official terms.
