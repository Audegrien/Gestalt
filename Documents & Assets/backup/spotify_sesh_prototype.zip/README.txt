SPOTIFY SESH PLAYER — PROTOTYPE

This is Step 1 of the custom Spotify Sesh Player.

WHAT IT DOES
- Lets you upload PNG/JPG/WebP/GIF playlist artwork.
- Keeps that artwork as the fullscreen background.
- Shows fake/sample track information.
- Shows fake synced lyrics.
- Shows a progress bar.
- Has a fullscreen button.
- Has a subtle grain/CRT-style texture.
- Treats the artwork as pixel art rather than replacing it with album artwork.

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in Chrome, Edge or another modern browser.
3. Click "Upload Playlist Artwork".
4. Select your custom 128x128 artwork.
5. Use F11 or the fullscreen button for the TV-style display.

CONTROLS
- Space = pause/resume the fake progress clock.
- F = toggle fullscreen.
- Move the mouse over the screen to reveal the controls.

IMPORTANT
This prototype does NOT connect to Spotify yet.
The sample track/lyrics are deliberately hard-coded.

NEXT STEP
Replace the sample track state with real Spotify playback data:
- track
- artist
- album artwork
- duration
- playback position
- play/pause state

Then add synced lyrics from a separate lyrics source.

NOTE ABOUT ARTWORK STORAGE
The browser prototype uses an object URL for the selected artwork, so the file is not permanently stored across browser sessions. In the eventual desktop app, the actual selected image will be copied/stored locally so the artwork persists properly.
