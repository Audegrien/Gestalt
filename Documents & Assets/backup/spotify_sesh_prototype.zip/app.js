const background = document.getElementById("background");
const setup = document.getElementById("setup");
const uploadButton = document.getElementById("uploadButton");
const artworkButton = document.getElementById("artworkButton");
const fileInput = document.getElementById("fileInput");
const fullscreenButton = document.getElementById("fullscreenButton");

const albumArt = document.getElementById("albumArt");
const trackTitle = document.getElementById("trackTitle");
const trackArtist = document.getElementById("trackArtist");
const previousLyric = document.getElementById("previousLyric");
const currentLyric = document.getElementById("currentLyric");
const nextLyric = document.getElementById("nextLyric");
const elapsed = document.getElementById("elapsed");
const duration = document.getElementById("duration");
const progressFill = document.getElementById("progressFill");
const progressDot = document.getElementById("progressDot");

// Prototype-only sample track/lyrics.
// Later this object will be populated from Spotify + a synced lyrics source.
const sampleTrack = {
  title: "Neon Static",
  artist: "The Midnight Echoes",
  duration: 222,
  albumArt: makePlaceholderAlbumArt(),
  lyrics: [
    [0,  "Streetlights flicker in the rain"],
    [12, "Neon bleeding through the glass"],
    [28, "We disappear into the night"],
    [47, "Like we were never here"],
    [66, "The city hums beneath our feet"],
    [88, "Every shadow knows our names"],
    [111, "Static dancing in the wires"],
    [136, "And the night keeps pulling us in"],
    [161, "Don't look back, just keep moving"],
    [188, "Until the morning finds us"],
    [210, "One more song before we go"]
  ]
};

let currentTime = 82;
let lastLyricIndex = -1;
let playing = true;

function makePlaceholderAlbumArt() {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#191919"/>
          <stop offset="1" stop-color="#626262"/>
        </linearGradient>
      </defs>
      <rect width="512" height="512" fill="url(#g)"/>
      <circle cx="256" cy="256" r="120" fill="none" stroke="#fff" stroke-opacity=".65" stroke-width="4"/>
      <path d="M145 318 L367 194 M145 194 L367 318" stroke="#fff" stroke-opacity=".65" stroke-width="4"/>
    </svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

function formatTime(seconds) {
  seconds = Math.max(0, Math.floor(seconds));
  const m = Math.floor(seconds / 60);
  const s = String(seconds % 60).padStart(2, "0");
  return `${m}:${s}`;
}

function renderTrack() {
  trackTitle.textContent = sampleTrack.title;
  trackArtist.textContent = sampleTrack.artist;
  albumArt.src = sampleTrack.albumArt;
  duration.textContent = formatTime(sampleTrack.duration);
}

function updateLyrics() {
  let index = 0;
  for (let i = 0; i < sampleTrack.lyrics.length; i++) {
    if (sampleTrack.lyrics[i][0] <= currentTime) index = i;
    else break;
  }

  if (index !== lastLyricIndex) {
    previousLyric.textContent = index > 0 ? sampleTrack.lyrics[index - 1][1] : "";
    currentLyric.textContent = sampleTrack.lyrics[index][1];
    nextLyric.textContent = index < sampleTrack.lyrics.length - 1
      ? sampleTrack.lyrics[index + 1][1]
      : "";
    lastLyricIndex = index;
  }
}

function updateProgress() {
  const ratio = Math.min(1, currentTime / sampleTrack.duration);
  const percent = ratio * 100;
  progressFill.style.width = `${percent}%`;
  progressDot.style.left = `${percent}%`;
  elapsed.textContent = formatTime(currentTime);
}

function tick() {
  if (playing) {
    currentTime += 0.25;
    if (currentTime >= sampleTrack.duration) currentTime = 0;
  }
  updateLyrics();
  updateProgress();
}

function loadArtwork(file) {
  if (!file || !file.type.startsWith("image/")) return;

  const url = URL.createObjectURL(file);
  background.style.backgroundImage = `url("${url}")`;

  // Keep the artwork between refreshes during this prototype.
  try {
    localStorage.setItem("spotifySeshArtwork", url);
  } catch {
    // Object URLs cannot reliably survive a page reload; this is only
    // a convenience. A desktop version will store the actual file.
  }

  setup.classList.add("hidden");
}

uploadButton.addEventListener("click", () => fileInput.click());
artworkButton.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", e => loadArtwork(e.target.files[0]));

fullscreenButton.addEventListener("click", async () => {
  try {
    if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
    else await document.exitFullscreen();
  } catch {}
});

// Space toggles the prototype playback clock.
document.addEventListener("keydown", e => {
  if (e.code === "Space" && !["INPUT", "TEXTAREA", "BUTTON"].includes(document.activeElement.tagName)) {
    e.preventDefault();
    playing = !playing;
  }
  if (e.key.toLowerCase() === "f") fullscreenButton.click();
});

renderTrack();
updateLyrics();
updateProgress();
setInterval(tick, 250);
