local old_ExperienceManager_get_contract_xp_by_stars = ExperienceManager.get_contract_xp_by_stars

function ExperienceManager:mission_xp_award(amount)
	local X = XP_Multiplier.settings.xp_multiplier_slider_value

	if amount > 0 then
		local current_xp = self._global.mission_xp_current and Application:digest_value(self._global.mission_xp_current, false) or 0
		self._global.mission_xp_current = Application:digest_value(current_xp + amount * X, true)
	end
end

function ExperienceManager:get_contract_xp_by_stars(job_id, job_stars, risk_stars, professional, job_days, extra_params)
	local total_xp, dissected_xp = old_ExperienceManager_get_contract_xp_by_stars(self, job_id, job_stars, risk_stars, professional, job_days, extra_params)
	local X = XP_Multiplier.settings.xp_multiplier_slider_value
	total_xp = 0

	for i, xp in ipairs(dissected_xp) do
		dissected_xp[i] = math.floor(xp * X)
		total_xp = total_xp + dissected_xp[i]
	end

	return total_xp, dissected_xp
end