_G.XP_Multiplier = XP_Multiplier or {}
XP_Multiplier.path = ModPath
XP_Multiplier.save_path = SavePath .. "xp_multiplier.txt"
XP_Multiplier.settings = {
    xp_multiplier_slider_value = 1
}

function XP_Multiplier:Save()
	local file = io.open(self.save_path,"w+")
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
end

function XP_Multiplier:Load()
	local file = io.open(self.save_path, "r")
	if (file) then
		for k, v in pairs(json.decode(file:read("*all"))) do
			self.settings[k] = v
		end
	else
		self:Save()
	end
end

Hooks:Add("LocalizationManagerPostInit", "XP_Multiplier_LocalizationManagerPostInit", function(loc)
	local t = XP_Multiplier.path .. "loc/"
	for _, filename in pairs(file.GetFiles(t)) do
		local str = filename:match('^(.*).txt$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			loc:load_localization_file(t .. filename)
			return
		end
	end
	loc:load_localization_file(t .. "english.txt")
end)

Hooks:Add("MenuManagerInitialize", "XP_Multiplier_MenuManagerInitialize", function(menu_manager)
	MenuCallbackHandler.xp_multiplier_slider_callback = function(self,item)
		local value = tonumber(item:value())
		XP_Multiplier.settings.xp_multiplier_slider_value = value
		XP_Multiplier:Save()
	end
	
	MenuCallbackHandler.xp_multiplier_back = function(self)
		XP_Multiplier:Save()
	end
	
	XP_Multiplier:Load()
	MenuHelper:LoadFromJsonFile(XP_Multiplier.path .. "menu/options.txt", XP_Multiplier, XP_Multiplier.settings)
end)